import Link from 'next/link';
import styles from '../styles/AdminDashboard.module.css';

const Sidebar: React.FC = () => {
  return (
    <div className={styles.sidebar}>
      <h2 className={styles.logo}>Pearls Admin</h2>
      <nav>
        <ul>
          <li>
            <Link href="/admin/add">Add Pearls</Link>
          </li>
          <li>
            <Link href="/admin/remove">Remove Pearls</Link>
          </li>
          <li>
            <Link href="/admin/update">Update Pearls</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
