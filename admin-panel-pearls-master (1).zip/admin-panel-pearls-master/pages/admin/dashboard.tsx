import AdminLayout from '../../components/AdminLayout';
import Header from '../../components/Header';

const Dashboard: React.FC = () => {
  return (
    <AdminLayout>
      <Header />
      <main>
        <p>Welcome to the Admin Dashboard! Use the sidebar to manage pearls.</p>
      </main>
    </AdminLayout>
  );
};

export default Dashboard;
