import AdminLayout from '../../components/AdminLayout';
import Header from '../../components/Header';
import { useState, useEffect } from 'react';

const RemovePearls: React.FC = () => {
  const [pearls, setPearls] = useState([]);

  useEffect(() => {
    const storedPearls = JSON.parse(localStorage.getItem('pearls')) || [];
    setPearls(storedPearls);
  }, []);

  const handleRemove = (id: number) => {
    const updatedPearls = pearls.filter(pearl => pearl.id !== id);
    if (updatedPearls.length !== pearls.length) {
      setPearls(updatedPearls);
      localStorage.setItem('pearls', JSON.stringify(updatedPearls));
    }
  };

  return (
    <AdminLayout>
      <Header />
      <main>
        <h2 style={{ textAlign: 'center', color: '#2E3A59' }}>Remove Pearls</h2>
        <p style={{ textAlign: 'center', color: '#6C757D' }}>Admins can view and remove pearls below.</p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px',
            padding: '20px',
          }}
        >
          {pearls.map(pearl => (
            <div
              key={pearl.id}
              style={{
                backgroundColor: '#F8F9FA',
                border: '1px solid #E0E0E0',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <img
                src={pearl.image}
                alt={pearl.name}
                style={{
                  width: '150px',
                  height: '150px',
                  objectFit: 'cover',
                  borderRadius: '8px',
                  marginBottom: '10px',
                }}
              />
              <h3 style={{ margin: '0 0 8px', textAlign: 'center', color: '#2E3A59' }}>{pearl.name}</h3>
              <p style={{ margin: '0 0 4px', color: '#495057' }}>
                <strong>Carat:</strong> {pearl.carat} ct
              </p>
              <p style={{ margin: '0 0 4px', color: '#495057' }}>
                <strong>Price per Carat:</strong> ${pearl.pricePerCarat}
              </p>
              <p style={{ margin: '0 0 4px', color: '#495057' }}>
                <strong>Total Price:</strong> ${pearl.total}
              </p>
              <p style={{ margin: '0 0 8px', color: '#495057' }}>
                <strong>Origin:</strong> {pearl.origin}
              </p>
              <button
                onClick={() => handleRemove(pearl.id)}
                style={{
                  backgroundColor: '#6C757D',
                  color: '#FFFFFF',
                  padding: '8px 12px',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        {pearls.length === 0 && (
          <p style={{ color: '#6C757D', fontStyle: 'italic', textAlign: 'center' }}>
            No pearls available to remove.
          </p>
        )}
      </main>
    </AdminLayout>
  );
};

export default RemovePearls;
