import AdminLayout from '../../components/AdminLayout';
import Header from '../../components/Header';
import { useState, useEffect } from 'react';

const AddPearls: React.FC = () => {
  const [pearlName, setPearlName] = useState('');
  const [pearlCarat, setPearlCarat] = useState('');
  const [pricePerCarat, setPricePerCarat] = useState('');
  const [totalPrice, setTotalPrice] = useState('');
  const [pearlOrigin, setPearlOrigin] = useState('');
  const [pearlImage, setPearlImage] = useState<File | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [pearls, setPearls] = useState([]);

  useEffect(() => {
    const storedPearls = JSON.parse(localStorage.getItem('pearls') || '[]');
    setPearls(storedPearls);
  }, []);

  const validateForm = () => {
    if (!pearlName || !pearlCarat || !pricePerCarat || !totalPrice || !pearlOrigin || !pearlImage) {
      alert('Please fill in all fields.');
      return false;
    }

    if (isNaN(Number(pearlCarat)) || isNaN(Number(pricePerCarat)) || isNaN(Number(totalPrice))) {
      alert('Please enter valid numbers for carat and prices.');
      return false;
    }

    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    const newPearl = {
      name: pearlName,
      carat: pearlCarat,
      pricePerCarat: pricePerCarat,
      totalPrice: totalPrice,
      origin: pearlOrigin,
      image: pearlImage ? URL.createObjectURL(pearlImage) : '',
    };

    const updatedPearls = [...pearls, newPearl];
    setPearls(updatedPearls);
    localStorage.setItem('pearls', JSON.stringify(updatedPearls));

    setPearlName('');
    setPearlCarat('');
    setPricePerCarat('');
    setTotalPrice('');
    setPearlOrigin('');
    setPearlImage(null);
    setShowModal(false);
  };

  return (
    <AdminLayout>
      <Header />
      <main style={{ padding: '20px', maxWidth: '1200px', margin: 'auto', fontFamily: 'Arial, sans-serif' }}>
        <h2 style={{ textAlign: 'center', color: '#333', marginBottom: '10px' }}>Add Pearls</h2>
        <button
          onClick={() => setShowModal(true)}
          style={{
            backgroundColor: '#FFC0CB', 
            color: 'white', 
            padding: '10px 20px', 
            border: 'none', 
            borderRadius: '6px', 
            cursor: 'pointer', 
            fontSize: '16px', 
            margin: 'auto', 
            display: 'block',
          }}
        >
          Add New Pearl
        </button>

        {showModal && (
          <div
            style={{
              position: 'fixed', 
              top: '0', 
              left: '0', 
              width: '100%', 
              height: '100%', 
              backgroundColor: 'rgba(0, 0, 0, 0.5)', 
              display: 'flex', 
              justifyContent: 'center', 
              alignItems: 'center', 
              zIndex: 1000,
            }}
          >
            <form
              onSubmit={handleSubmit}
              style={{
                backgroundColor: '#FFF0F5', 
                padding: '20px', 
                borderRadius: '8px', 
                maxWidth: '500px', 
                width: '100%', 
                boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
              }}
            >
              <h3 style={{ textAlign: 'center', color: '#FFC0CB', marginBottom: '20px' }}>Add New Pearl</h3>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="name" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Pearl Name:</label>
                <input
                  type="text"
                  id="name"
                  value={pearlName}
                  onChange={(e) => setPearlName(e.target.value)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="carat" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Carat:</label>
                <input
                  type="text"
                  id="carat"
                  value={pearlCarat}
                  onChange={(e) => setPearlCarat(e.target.value)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="price" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Price Per Carat:</label>
                <input
                  type="text"
                  id="price"
                  value={pricePerCarat}
                  onChange={(e) => setPricePerCarat(e.target.value)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="total" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Total Price:</label>
                <input
                  type="text"
                  id="total"
                  value={totalPrice}
                  onChange={(e) => setTotalPrice(e.target.value)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="origin" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Origin:</label>
                <input
                  type="text"
                  id="origin"
                  value={pearlOrigin}
                  onChange={(e) => setPearlOrigin(e.target.value)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="image" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Pearl Image:</label>
                <input
                  type="file"
                  id="image"
                  onChange={(e) => setPearlImage(e.target.files?.[0] || null)}
                  required
                  style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd' }}
                />
              </div>

              <button
                type="submit"
                style={{
                  backgroundColor: '#FFC0CB', 
                  color: 'white', 
                  padding: '10px 20px', 
                  border: 'none', 
                  borderRadius: '6px', 
                  cursor: 'pointer', 
                  width: '100%',
                }}
              >
                Add Pearl
              </button>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                style={{
                  marginTop: '10px',
                  backgroundColor: '#f44336',
                  color: 'white',
                  padding: '10px 20px',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  width: '100%',
                }}
              >
                Cancel
              </button>
            </form>
          </div>
        )}

        <h3 style={{ textAlign: 'center', marginTop: '40px', color: '#333' }}>Pearls List:</h3>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '20px',
            marginTop: '20px',
          }}
        >
          {pearls.map((pearl, index) => (
            <div
              key={index}
              style={{
                backgroundColor: '#f9f9f9',
                padding: '20px',
                borderRadius: '10px',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                textAlign: 'center',
              }}
            >
              {pearl.image && (
                <img
                  src={pearl.image}
                  alt={pearl.name}
                  style={{
                    width: '100%',
                    height: '200px',
                    objectFit: 'cover',
                    borderRadius: '10px',
                    marginBottom: '15px',
                  }}
                />
              )}
              <h4 style={{ margin: '0 0 10px 0', color: '#333' }}>{pearl.name}</h4>
              <p style={{ margin: '0', color: '#555' }}>Carat: {pearl.carat}</p>
              <p style={{ margin: '0', color: '#555' }}>Price/Carat: ${pearl.pricePerCarat}</p>
              <p style={{ margin: '0', color: '#555' }}>Total Price: ${pearl.totalPrice}</p>
              <p style={{ margin: '0', color: '#555' }}>Origin: {pearl.origin}</p>
            </div>
          ))}
        </div>
      </main>
    </AdminLayout>
  );
};

export default AddPearls;
