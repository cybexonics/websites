import AdminLayout from '../../components/AdminLayout';
import Header from '../../components/Header';
import { useState, useEffect } from 'react';

const UpdatePearls: React.FC = () => {
  const [pearls, setPearls] = useState([]);
  const [selectedPearl, setSelectedPearl] = useState(null);
  const [newName, setNewName] = useState('');
  const [newOrigin, setNewOrigin] = useState('');
  const [newCarat, setNewCarat] = useState('');
  const [newPricePerCarat, setNewPricePerCarat] = useState('');

  useEffect(() => {
    // Retrieve pearls data from local storage
    const storedPearls = localStorage.getItem('pearls');
    if (storedPearls) {
      setPearls(JSON.parse(storedPearls));
    }
  }, []);

  const handleUpdateClick = (pearl) => {
    setSelectedPearl(pearl);
    setNewName(pearl.name);
    setNewOrigin(pearl.origin);
    setNewCarat(pearl.carat.toString());
    setNewPricePerCarat(pearl.pricePerCarat.toString());
  };

  const handleUpdateSubmit = (e) => {
    e.preventDefault();
    const updatedPearls = pearls.map(pearl =>
      pearl.id === selectedPearl.id ? {
        ...pearl,
        name: newName,
        origin: newOrigin,
        carat: parseFloat(newCarat),
        pricePerCarat: parseFloat(newPricePerCarat),
        total: parseFloat(newCarat) * parseFloat(newPricePerCarat),
      } : pearl
    );

    setPearls(updatedPearls);
    localStorage.setItem('pearls', JSON.stringify(updatedPearls));
    setSelectedPearl(null);
    setNewName('');
    setNewOrigin('');
    setNewCarat('');
    setNewPricePerCarat('');
  };

  return (
    <AdminLayout>
      <Header />
      <main style={{ padding: '20px', maxWidth: '1200px', margin: 'auto', fontFamily: 'Arial, sans-serif' }}>
        <h2 style={{ textAlign: 'center', color: '#333', marginBottom: '10px' }}>Update Pearls</h2>
        <p style={{ textAlign: 'center', color: '#555', fontSize: '1.1rem', marginBottom: '30px' }}>
          This is the page where admins can update pearls with a more creative and interactive design.
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px',
            padding: '20px',
          }}
        >
          {pearls.map((pearl) => (
            <div
              key={pearl.id}
              style={{
                backgroundColor: '#fff',
                border: '1px solid #ddd',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <img
                src={pearl.image}
                alt={pearl.name}
                style={{
                  width: '150px',
                  height: '150px',
                  objectFit: 'cover',
                  borderRadius: '8px',
                  marginBottom: '10px',
                }}
              />
              <h3 style={{ margin: '0 0 8px', textAlign: 'center' }}>{pearl.name}</h3>
              <p style={{ margin: '0 0 4px' }}>
                <strong>Carat:</strong> {pearl.carat} ct
              </p>
              <p style={{ margin: '0 0 4px' }}>
                <strong>Price per Carat:</strong> ${pearl.pricePerCarat}
              </p>
              <p style={{ margin: '0 0 8px' }}>
                <strong>Total Price:</strong> ${pearl.total}
              </p>
              <p style={{ margin: '0 0 8px' }}>
                <strong>Origin:</strong> {pearl.origin}
              </p>
              <button
                onClick={() => handleUpdateClick(pearl)}
                style={{
                  backgroundColor: '#4CAF50',
                  color: '#fff',
                  padding: '8px 12px',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                }}
              >
                Update
              </button>
            </div>
          ))}
        </div>

        {selectedPearl && (
          <div
            style={{
              position: 'fixed',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              zIndex: 1000,
            }}
          >
            <div
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                padding: '20px',
                width: '90%',
                maxWidth: '400px',
                animation: 'fadeIn 0.3s ease-in-out',
              }}
            >
              <h3 style={{ textAlign: 'center', color: '#4CAF50', marginBottom: '20px' }}>Update Pearl</h3>
              <form onSubmit={handleUpdateSubmit}>
                <div style={{ marginBottom: '15px' }}>
                  <label htmlFor="name" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px', color: '#555' }}>Name:</label>
                  <input
                    type="text"
                    id="name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    required
                    style={{
                      padding: '10px',
                      marginTop: '5px',
                      width: '100%',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      fontSize: '1rem',
                      transition: 'border 0.3s ease',
                    }}
                  />
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label htmlFor="origin" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px', color: '#555' }}>Origin:</label>
                  <input
                    type="text"
                    id="origin"
                    value={newOrigin}
                    onChange={(e) => setNewOrigin(e.target.value)}
                    required
                    style={{
                      padding: '10px',
                      marginTop: '5px',
                      width: '100%',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      fontSize: '1rem',
                      transition: 'border 0.3s ease',
                    }}
                  />
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label htmlFor="carat" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px', color: '#555' }}>Carat:</label>
                  <input
                    type="number"
                    id="carat"
                    value={newCarat}
                    onChange={(e) => setNewCarat(e.target.value)}
                    required
                    style={{
                      padding: '10px',
                      marginTop: '5px',
                      width: '100%',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      fontSize: '1rem',
                      transition: 'border 0.3s ease',
                    }}
                  />
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label htmlFor="pricePerCarat" style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px', color: '#555' }}>Price per Carat:</label>
                  <input
                    type="number"
                    id="pricePerCarat"
                    value={newPricePerCarat}
                    onChange={(e) => setNewPricePerCarat(e.target.value)}
                    required
                    style={{
                      padding: '10px',
                      marginTop: '5px',
                      width: '100%',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      fontSize: '1rem',
                      transition: 'border 0.3s ease',
                    }}
                  />
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <button
                    type="submit"
                    style={{
                      backgroundColor: '#4CAF50',
                      color: 'white',
                      padding: '12px 20px',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      flexGrow: 1,
                      marginRight: '10px',
                      transition: 'background-color 0.3s ease',
                    }}
                  >
                    Save Changes
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedPearl(null)}
                    style={{
                      backgroundColor: '#f44336',
                      color: 'white',
                      padding: '12px 20px',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      flexGrow: 1,
                      transition: 'background-color 0.3s ease',
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </AdminLayout>
  );
};

export default UpdatePearls;
