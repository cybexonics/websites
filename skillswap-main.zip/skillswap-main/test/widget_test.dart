import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skillswap/screens/CreateProfileScreen.dart';
import 'package:skillswap/screens/login_screen.dart'; // Ensure this is the correct import path


void main() {
  testWidgets('Login Page UI Test', (WidgetTester tester) async {
    // Wrap with MaterialApp only once to avoid multiple Navigator GlobalKey conflicts
    await tester.pumpWidget(
      const MaterialApp(
        home: LoginScreen(),
      ),
    );

    // Define test keys to identify widgets precisely
    final emailField = find.byKey(const Key('emailField'));
    final passwordField = find.byKey(const Key('passwordField'));
    final loginButton = find.byKey(const Key('loginButton'));

    // Check if email & password fields are present
    expect(emailField, findsOneWidget);
    expect(passwordField, findsOneWidget);

    // Check if login button is present
    expect(loginButton, findsOneWidget);

    // Enter text in email and password fields
    await tester.enterText(emailField, 'test@example.com');
    await tester.enterText(passwordField, 'password123');

    // Tap the login button
    await tester.tap(loginButton);
    await tester.pumpAndSettle();

    // Debug print to track navigation
    debugPrint('Navigating to CreateProfileScreen...');

    // Check if navigation happens correctly
    expect(find.byType(CreateProfileScreen), findsOneWidget);
  });
}
