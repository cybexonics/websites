import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF6C5CE7);

const TextStyle titleTextStyle = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.bold,
  color: Color.fromARGB(255, 11, 11, 11),
);

const TextStyle subtitleTextStyle = TextStyle(
  fontSize: 16,
  color: Color.fromARGB(136, 24, 23, 23),
);

const TextStyle buttonTextStyle = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.bold,
);

const TextStyle linkTextStyle = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.bold,
  color: primaryColor,
);

InputDecoration inputDecoration(String label, String hint) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    filled: true,
    fillColor: Colors.grey[50],
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
  );
}
