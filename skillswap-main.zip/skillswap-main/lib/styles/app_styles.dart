import 'package:flutter/material.dart';

class AppStyles {
  static const TextStyle headingText = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
  );

  static final InputDecoration searchInputDecoration = InputDecoration(
    hintText: 'Search skills or people...',
    prefixIcon: const Icon(Icons.search),
    filled: true,
    fillColor: Colors.grey[100],
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12), // Removed 'const'
      borderSide: BorderSide.none,
    ),
  );
}
