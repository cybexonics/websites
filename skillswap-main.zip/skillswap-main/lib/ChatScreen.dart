import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:skillswap/ChatlistScreen.dart';
// import 'chat_detail_screen.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key, required ChatContact contact});

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final String userName = "Johan";
  int _selectedTabIndex = 0;
  final List<String> _tabs = ["All Chats", "Groups", "Contacts"];

  final List<ChatContact> _contacts = [
    ChatContact(
      name: "Larry Machigo",
      status: "Online",
      imageUrl: "https://randomuser.me/api/portraits/men/32.jpg",
      lastMessage: "OK, Let me check",
      lastMessageTime: DateTime.now().subtract(const Duration(hours: 1)),
      isOnline: true,
    ),
    ChatContact(
      name: "Natalie Nora",
      status: "Online",
      imageUrl: "https://randomuser.me/api/portraits/women/44.jpg",
      lastMessage: "Natalie is typing...",
      lastMessageTime: DateTime.now().subtract(const Duration(hours: 2)),
      isTyping: true,
      unreadCount: 2,
    ),
    ChatContact(
      name: "Jennifer Jones",
      status: "Last seen 2 hours ago",
      imageUrl: "https://randomuser.me/api/portraits/women/65.jpg",
      lastMessage: "Voice message",
      lastMessageTime: DateTime.now().subtract(const Duration(hours: 3)),
      unreadCount: 0,
    ),
    ChatContact(
      name: "Larry Machigo",
      status: "Last seen yesterday",
      imageUrl: "https://randomuser.me/api/portraits/men/22.jpg",
      lastMessage: "See you tomorrow, take...",
      lastMessageTime: DateTime.now().subtract(const Duration(days: 1)),
    ),
    ChatContact(
      name: "Sofia",
      status: "Last seen 3 days ago",
      imageUrl: "https://randomuser.me/api/portraits/women/26.jpg",
      lastMessage: "Oh... thank you so...",
      lastMessageTime: DateTime.now().subtract(const Duration(days: 5)),
    ),
    ChatContact(
      name: "Haider Lee",
      status: "Online",
      imageUrl: "https://randomuser.me/api/portraits/men/36.jpg",
      lastMessage: "👍 Sticker",
      lastMessageTime: DateTime.now().subtract(const Duration(days: 18)),
    ),
    ChatContact(
      name: "Mr. elon",
      status: "Last seen 1 week ago",
      imageUrl: "https://randomuser.me/api/portraits/men/41.jpg",
      lastMessage: "Cool 😎",
      lastMessageTime: DateTime.now().subtract(const Duration(days: 20)),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              _buildTabs(),
              const SizedBox(height: 24),
              Expanded(
                child: _buildChatList(),
              ),
              _buildFloatingActionButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.only(top: 16.0),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Hello,",
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                userName,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ],
          ),
          const Spacer(),
          CircleAvatar(
            backgroundColor: Colors.grey.shade100,
            radius: 20,
            child: IconButton(
              icon: const Icon(
                Icons.search,
                color: Colors.grey,
              ),
              onPressed: () {},
            ),
          ),
          const SizedBox(width: 8),
          CircleAvatar(
            backgroundColor: Colors.grey.shade100,
            radius: 20,
            child: IconButton(
              icon: const Icon(
                Icons.more_vert,
                color: Colors.grey,
              ),
              onPressed: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: List.generate(
          _tabs.length,
          (index) => Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedTabIndex = index;
                });
              },
              child: Container(
                decoration: BoxDecoration(
                  color: _selectedTabIndex == index
                      ? const Color(0xFF6C5CE7)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Text(
                    _tabs[index],
                    style: TextStyle(
                      color: _selectedTabIndex == index
                          ? Colors.white
                          : Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildChatList() {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: _contacts.length,
      itemBuilder: (context, index) {
        final contact = _contacts[index];
        return _buildChatItem(contact);
      },
    );
  }

  Widget _buildChatItem(ChatContact contact) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChatDetailScreen(contact: contact),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundImage: NetworkImage(contact.imageUrl),
                ),
                if (contact.isOnline)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        contact.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        _formatTime(contact.lastMessageTime),
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (contact.lastMessage.contains("Voice"))
                        const Icon(
                          Icons.mic,
                          size: 14,
                          color: Colors.grey,
                        ),
                      if (contact.lastMessage.contains("Voice"))
                        const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          contact.lastMessage,
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 13,
                            fontWeight: contact.isTyping
                                ? FontWeight.w500
                                : FontWeight.normal,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (contact.unreadCount > 0) ...[
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: Color(0xFF6C5CE7),
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            contact.unreadCount.toString(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return Align(
      alignment: Alignment.bottomRight,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: FloatingActionButton(
          backgroundColor: const Color(0xFF6C5CE7),
          child: const Icon(Icons.refresh),
          onPressed: () {},
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final messageDate = DateTime(time.year, time.month, time.day);

    if (messageDate == today) {
      return DateFormat.jm().format(time); // Format as 9:30 AM
    } else if (messageDate == yesterday) {
      return "Yesterday";
    } else if (now.difference(time).inDays < 7) {
      return DateFormat('E').format(time); // Format as Mon, Tue, etc.
    } else if (now.year == time.year) {
      return "${time.day} ${DateFormat('MMM').format(time)}"; // Format as 12 Jun
    } else {
      return DateFormat('dd/MM/yy').format(time); // Format as 12/06/22
}
}
}
