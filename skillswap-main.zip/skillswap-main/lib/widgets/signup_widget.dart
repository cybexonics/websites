import 'package:flutter/material.dart';
import 'package:skillswap/styles/signup_style.dart';


Widget buildHeaderIcon() {
  return Column(
    children: [
      const SizedBox(height: 32),
      Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.person_add, color: Colors.white, size: 36),
      ),
      const SizedBox(height: 24),
    ],
  );
}

Widget buildTitle() {
  return Column(
    children: const [
      Text(
        'Join SkillSwap Today!',
        style: titleTextStyle,
      ),
      SizedBox(height: 8),
      Text(
        'Connect, Learn, Grow Together',
        textAlign: TextAlign.center,
        style: subtitleTextStyle,
      ),
      SizedBox(height: 32),
    ],
  );
}

Widget buildTextField({
  required String labelText,
  required String hintText,
  TextInputType keyboardType = TextInputType.text,
  Function(String?)? onSaved,
  String? Function(String?)? validator,
}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 16),
    child: TextFormField(
      keyboardType: keyboardType,
      decoration: inputDecoration(labelText, hintText),
      onSaved: onSaved,
      validator: validator,
    ),
  );
}

Widget buildPasswordField({
  required String labelText,
  required String hintText,
  required bool isPasswordVisible,
  required VoidCallback toggleVisibility,
  Function(String?)? onSaved,
  String? Function(String?)? validator, required Function(dynamic value) onChanged,
}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 16),
    child: TextFormField(
      obscureText: !isPasswordVisible,
      decoration: inputDecoration(labelText, hintText).copyWith(
        suffixIcon: IconButton(
          icon: Icon(isPasswordVisible ? Icons.visibility_off : Icons.visibility, color: Colors.grey),
          onPressed: toggleVisibility,
        ),
      ),
      onSaved: onSaved,
      validator: validator,
    ),
  );
}

Widget buildSignUpButton(VoidCallback onPressed, {Color textColor = const Color.fromARGB(255, 253, 251, 251)}) {
  return Padding(
    padding: const EdgeInsets.only(top: 24),
    child: SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: Text(
          'Sign Up',
          style: buttonTextStyle.copyWith(color: textColor),
        ),
      ),
    ),
  );
}


Widget buildLoginOption(BuildContext context) {
  return Padding(
    padding: const EdgeInsets.only(top: 24),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Already have an account? ", style: subtitleTextStyle),
        GestureDetector(
          onTap: () => Navigator.pushNamed(context, '/login'),
          child: const Text('Log In', style: linkTextStyle),
        ),
      ],
    ),
  );
}
