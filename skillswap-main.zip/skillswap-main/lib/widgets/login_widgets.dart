import 'package:flutter/material.dart';
import 'package:skillswap/screens/signup_screen.dart';
import 'package:skillswap/styles/login_styles.dart';

class ProfileIcon extends StatelessWidget {
  const ProfileIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 80,
        height: 80,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF6C5CE7),
        ),
        child: const Icon(Icons.person, size: 40, color: Colors.white),
      ),
    );
  }
}

class WelcomeText extends StatelessWidget {
  const WelcomeText({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text('Welcome Back!', textAlign: TextAlign.center, style: LoginStyles.welcomeTextStyle),
        const SizedBox(height: 8),
        Text('Sign in to continue', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[600], fontSize: 16)),
      ],
    );
  }
}

class EmailField extends StatelessWidget {
  final TextEditingController controller;
  final String? Function(String?)? validator;

  const EmailField({super.key, required this.controller, required this.validator});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: const Key('emailField'),
      controller: controller,
      decoration: LoginStyles.inputDecoration('Email', 'Enter your email'),
      keyboardType: TextInputType.emailAddress,
      validator: validator,
    );
  }
}

class PasswordField extends StatelessWidget {
  final TextEditingController controller;
  final bool isPasswordVisible;
  final VoidCallback toggleVisibility;
  final String? Function(String?)? validator;

  const PasswordField({
    super.key,
    required this.controller,
    required this.isPasswordVisible,
    required this.toggleVisibility,
    required this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: const Key('passwordField'),
      controller: controller,
      obscureText: !isPasswordVisible,
      decoration: LoginStyles.inputDecoration('Password', 'Enter your password').copyWith(
        suffixIcon: IconButton(
          icon: Icon(isPasswordVisible ? Icons.visibility_off : Icons.visibility, color: Colors.grey),
          onPressed: toggleVisibility,
        ),
      ),
      validator: validator,
    );
  }
}

class LoginButton extends StatelessWidget {
  final VoidCallback onPressed;
  const LoginButton({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      key: const Key('loginButton'),
      onPressed: onPressed,
      style: LoginStyles.loginButtonStyle,
      child: const Text('Log in', style: TextStyle(fontSize: 16, color: Colors.white)),
    );
  }
}

Widget SignUpText(BuildContext context) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Text("Don't have an account?", style: TextStyle(fontSize: 16, color: Colors.black54)),
      TextButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SignUpScreen())),
        child: const Text('Sign Up', style: LoginStyles.signUpTextStyle),
      ),
    ],
  );
}
