import 'dart:io';
import 'package:flutter/material.dart';


class ProfileImagePicker extends StatelessWidget {
  final File? profileImage;
  final VoidCallback onPickImage;

  const ProfileImagePicker({
    Key? key,
    required this.profileImage,
    required this.onPickImage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: GestureDetector(
        onTap: onPickImage,
        child: CircleAvatar(
          radius: 50,
          backgroundColor: Colors.grey[200],
          backgroundImage: profileImage != null ? FileImage(profileImage!) : null,
          child: profileImage == null ? const Icon(Icons.add, size: 40, color: Colors.grey) : null,
        ),
      ),
    );
  }
}

class SkillTagWidget extends StatelessWidget {
  final List<String> skills;
  final Function(String) onRemoveSkill;
  final VoidCallback onAddSkill;

  const SkillTagWidget({
    Key? key,
    required this.skills,
    required this.onRemoveSkill,
    required this.onAddSkill,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      children: [
        ...skills.map((skill) => Chip(
              label: Text(skill),
              onDeleted: () => onRemoveSkill(skill),
            )),
        ActionChip(
          label: const Text('Add Skill'),
          avatar: const Icon(Icons.add, size: 18),
          onPressed: onAddSkill,
        ),
      ],
    );
  }
}

class UploadAreaWidget extends StatelessWidget {
  final VoidCallback onPickFile;
  final File? uploadedFile;

  const UploadAreaWidget({
    Key? key,
    required this.onPickFile,
    required this.uploadedFile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: onPickFile,
          child: const Text("Upload File"),
        ),
        if (uploadedFile != null) 
          Text("Selected: ${uploadedFile!.path.split('/').last}"),
      ],
    );
  }
}

class AvailabilityGridWidget extends StatelessWidget {
  final bool weekdayMornings;
  final bool weekdayEvenings;
  final bool weekendMornings;
  final bool weekendEvenings;
  final ValueChanged<bool> onChanged;

  const AvailabilityGridWidget({
    Key? key,
    required this.weekdayMornings,
    required this.weekdayEvenings,
    required this.weekendMornings,
    required this.weekendEvenings,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CheckboxListTile(
          title: const Text('Weekday Mornings'),
          value: weekdayMornings,
          onChanged: (val) => onChanged(val!),
        ),
        CheckboxListTile(
          title: const Text('Weekday Evenings'),
          value: weekdayEvenings,
          onChanged: (val) => onChanged(val!),
        ),
        CheckboxListTile(
          title: const Text('Weekend Mornings'),
          value: weekendMornings,
          onChanged: (val) => onChanged(val!),
        ),
        CheckboxListTile(
          title: const Text('Weekend Evenings'),
          value: weekendEvenings,
          onChanged: (val) => onChanged(val!),
        ),
      ],
    );
  }
}

class LocationTextField extends StatelessWidget {
  final TextEditingController locationController;
  final VoidCallback onGetLocation;

  const LocationTextField({
    Key? key,
    required this.locationController,
    required this.onGetLocation,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onGetLocation,
      child: AbsorbPointer(
        child: TextField(
          controller: locationController,
          decoration: InputDecoration(
            hintText: 'Enter your city',
            prefixIcon: IconButton(
              icon: const Icon(Icons.location_on_outlined),
              onPressed: onGetLocation,
            ),
          ),
        ),
      ),
    );
  }
}
