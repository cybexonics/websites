import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class PremiumPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Go Premium',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 30),
              _buildLottieAnimation(),
              SizedBox(height: 20),
              _buildTitle(),
              SizedBox(height: 10),
              _buildDescription(),
              SizedBox(height: 30),
              _buildPremiumCard(context, 'Standard Premium', '\$9.99/month',
                  '• Priority Skill Matching\n• Unlimited Listings\n• No Ads'),
              SizedBox(height: 20),
              _buildPremiumCard(context, 'Elite Premium', '\$19.99/month',
                  '• All Standard Benefits\n• One-on-One Coaching\n• Featured Profile'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLottieAnimation() {
    return Lottie.asset(
      'assets/lottie/premium.json',
      height: 200,
      errorBuilder: (context, error, stackTrace) => Icon(
        Icons.star,
        size: 100,
        color: Colors.amber,
      ),
    );
  }

  Widget _buildTitle() {
    return Text(
      'Unlock Premium Features!',
      style: GoogleFonts.poppins(
        fontSize: 24,
        fontWeight: FontWeight.bold,
      ),
      textAlign: TextAlign.center,
    );
  }

  Widget _buildDescription() {
    return Text(
      'Get exclusive access to advanced features, priority matching, and an ad-free experience.',
      style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey[700]),
      textAlign: TextAlign.center,
    );
  }

  Widget _buildPremiumCard(BuildContext context, String title, String price, String benefits) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 5),
          Text(
            price,
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.amber,
            ),
          ),
          SizedBox(height: 10),
          Text(
            benefits,
            style: GoogleFonts.poppins(fontSize: 16, color: Colors.white70),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // Implement payment logic
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber,
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Subscribe',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
