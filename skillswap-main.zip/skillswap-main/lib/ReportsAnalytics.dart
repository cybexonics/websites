import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class ReportsAnalyticsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Reports & Analytics",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 22),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        shadowColor: Colors.grey[300],
      ),
      body: const ReportsAndAnalyticsContent(),
      backgroundColor: Colors.grey[100],
    );
  }
}

class ReportsAndAnalyticsContent extends StatefulWidget {
  const ReportsAndAnalyticsContent({Key? key}) : super(key: key);

  @override
  _ReportsAndAnalyticsContentState createState() => _ReportsAndAnalyticsContentState();
}

class _ReportsAndAnalyticsContentState extends State<ReportsAndAnalyticsContent>
    with SingleTickerProviderStateMixin {
  final List<Map<String, dynamic>> userData = const [
    {'name': 'User 1', 'growth': 20},
    {'name': 'User 2', 'growth': 35},
    {'name': 'User 3', 'growth': 50},
    {'name': 'User 4', 'growth': 15},
    {'name': 'User 5', 'growth': 60},
  ];

  final Map<String, dynamic> platformMetrics = const {
    'totalUsers': 12000,
    'newUsers': 500,
    'activeUsers': 8000,
    'revenue': 25000.00,
    'dailyEngagement': 75,
    'monthlyRetention': 60,
    'userRating': 4.5,
  };

  double animationProgress = 0.0;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 300), () {
      setState(() {
        animationProgress = 1.0; // Animate the chart
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle("📊 User Growth Data"),
          _buildCard(_buildAnimatedBarChart()),
          const SizedBox(height: 20),

          _buildSectionTitle("💰 Revenue Distribution"),
          _buildCard(_buildAnimatedPieChart()),
          const SizedBox(height: 20),

          _buildSectionTitle("📈 Platform Engagement Trend"),
          _buildCard(_buildAnimatedLineChart()),
        ],
      ),
    );
  }

  Widget _buildAnimatedBarChart() {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: animationProgress),
      duration: const Duration(seconds: 2),
      curve: Curves.easeOutExpo,
      builder: (context, value, child) {
        return SizedBox(
          height: 260,
          child: BarChart(
            BarChartData(
              barGroups: [
                _barGroup(0, platformMetrics['dailyEngagement'].toDouble() * value, Colors.green),
                _barGroup(1, platformMetrics['monthlyRetention'].toDouble() * value, Colors.blue),
                _barGroup(2, (platformMetrics['userRating'] * 20).toDouble() * value, Colors.orange),
              ],
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      return Text(["Engagement", "Retention", "Rating"][value.toInt()]);
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  BarChartGroupData _barGroup(int x, double y, Color color) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: y,
          color: color.withOpacity(0.8),
          width: 22,
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            colors: [color, color.withOpacity(0.5)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ],
    );
  }

  Widget _buildAnimatedPieChart() {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: animationProgress),
      duration: const Duration(seconds: 2),
      curve: Curves.easeOutExpo,
      builder: (context, value, child) {
        return SizedBox(
          height: 260,
          child: PieChart(
            PieChartData(
              sections: [
                _pieSection(platformMetrics['activeUsers'].toDouble() * value, "Active", Colors.green),
                _pieSection(platformMetrics['newUsers'].toDouble() * value, "New", Colors.blue),
                _pieSection(
                    (platformMetrics['totalUsers'] - platformMetrics['activeUsers']).toDouble() * value,
                    "Inactive",
                    Colors.red),
              ],
            ),
          ),
        );
      },
    );
  }

  PieChartSectionData _pieSection(double value, String title, Color color) {
    return PieChartSectionData(
      value: value,
      title: title,
      color: color,
      radius: 55,
      titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
    );
  }

  Widget _buildAnimatedLineChart() {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: animationProgress),
      duration: const Duration(seconds: 2),
      curve: Curves.easeOutExpo,
      builder: (context, value, child) {
        return SizedBox(
          height: 260,
          child: LineChart(
            LineChartData(
              lineBarsData: [
                LineChartBarData(
                  spots: List.generate(
                    userData.length,
                    (index) => FlSpot((index + 1).toDouble(), userData[index]['growth'].toDouble() * value),
                  ),
                  isCurved: true,
                 color: Colors.blue,

                  barWidth: 4,
                  dotData: FlDotData(show: true),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      colors: [Colors.blue.withOpacity(0.5), Colors.blue.withOpacity(0.1)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ],
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      return Text(["User 1", "User 2", "User 3", "User 4", "User 5"][value.toInt() - 1]);
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Text(
        title,
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue),
      ),
    );
  }

  Widget _buildCard(Widget child) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 10, spreadRadius: 2)
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: child,
    );
  }
}
