import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:skillswap/AiModel.dart';
import 'package:skillswap/Community.dart';
import 'package:skillswap/Monetization.dart';
import 'package:skillswap/screens/skill_match_screen.dart';
import 'user_management.dart';
import 'SkillMonitoring.dart';  // Import SkillMonitoring.dart
import 'ReportsAnalytics.dart';  // Import the ReportsAnalytics.dart file

void main() {
  runApp(AdminDashboard());
}

class AdminDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue, brightness: Brightness.dark),
      home: AdminHomePage(),
    );
  }
}

class AdminHomePage extends StatefulWidget {
  @override
  _AdminHomePageState createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    UserManagementPage(),
    SkillMonitoringPage(),
    ReportsAnalyticsPage(),  // This will now open Reports & Analytics page
    AiModelPage(),
    CommunityPage(),
    MonetizationPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Admin Dashboard", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blueAccent,
        actions: [
         IconButton(
  icon: Icon(FontAwesomeIcons.home),  // Changed to home icon
  onPressed: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SkillMatchScreen(userProfile: {}, loggedInUserId: '',)),
    );  // Navigate to SkillMatchScreen
  },
),


        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.black87,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(color: Colors.blueAccent),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(FontAwesomeIcons.userShield, size: 48, color: Colors.white),
                    SizedBox(height: 10),
                    Text("Admin Panel", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              _drawerItem("User Management", FontAwesomeIcons.users, 0),
              _drawerItem("Skill Monitoring", FontAwesomeIcons.chartBar, 1),
              _drawerItem("Reports & Analytics", FontAwesomeIcons.fileAlt, 2),  // Link to Reports & Analytics page
              _drawerItem("AI Updates", FontAwesomeIcons.robot, 3),
              _drawerItem("Community Moderation", FontAwesomeIcons.comments, 4),
              _drawerItem("Monetization", FontAwesomeIcons.dollarSign, 5),
            ],
          ),
        ),
      ),
      body: _pages[_selectedIndex],  // Render selected page
    );
  }

  ListTile _drawerItem(String title, IconData icon, int index) {
    return ListTile(
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: TextStyle(color: Colors.white)),
      onTap: () {
        setState(() {
          _selectedIndex = index;  // Set the selected index for navigation
        });
        Navigator.pop(context);  // Close the drawer
      },
    );
  }
}






