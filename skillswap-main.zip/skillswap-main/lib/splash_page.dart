import 'package:flutter/material.dart';

import 'dart:async';

import 'package:skillswap/screens/signup_screen.dart'; // Import Timer

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  double progress = 0.0;
  bool isDownloading = false;

  // Simulate a download process with controlled speed
  void startDownload() {
    setState(() {
      isDownloading = true;
    });

    // Using Timer.periodic for smoother progress updates
    Timer.periodic(Duration(milliseconds: 100), (timer) {
      if (progress < 1.0) {
        setState(() {
          progress += 0.05; // Adjust the increment to control speed
        });
      } else {
        timer.cancel(); // Stop the timer when download is complete
        setState(() {
          isDownloading = false;
        });
        // Delay before navigating to the signup page for better UX
        Future.delayed(Duration(milliseconds: 500), () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SignUpScreen()),
          );
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();
    startDownload(); // Start the download when the page loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFF2F2), // Lighter background color for better contrast
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'SKILLswap',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            isDownloading
                ? CircularProgressIndicator(value: progress)
                : Icon(Icons.check_circle, color: Colors.green, size: 50),
            SizedBox(height: 20),
            Text(
              '${(progress * 100).toInt()}%',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
