import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:http/http.dart' as http;

class ReschedulePopup extends StatefulWidget {
  @override
  _ReschedulePopupState createState() => _ReschedulePopupState();
}

class _ReschedulePopupState extends State<ReschedulePopup> {
  DateTime _selectedDay = DateTime.now();
  String? _selectedTime;
  String? _selectedDuration;
  String? _selectedLocation;

  final List<String> _timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM',
    '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM'
  ];
  final List<String> _durations = ['30 min', '1 hour', '2 hours'];
  final List<String> _locations = ['Remote', 'Face-to-Face'];

  Widget _buildChoiceChips(List<String> options, String? selectedValue, Function(String) onSelected) {
    return Wrap(
      spacing: 8,
      children: options.map((option) {
        return ChoiceChip(
          label: Text(option, style: TextStyle(fontSize: 14)),
          selected: selectedValue == option,
          onSelected: (selected) {
            if (selected) {
              setState(() => onSelected(option));
            }
          },
          selectedColor: Colors.deepPurpleAccent,
          backgroundColor: const Color.fromARGB(255, 255, 255, 255),
          labelStyle: TextStyle(color: selectedValue == option ? Colors.white : Colors.black),
        );
      }).toList(),
    );
  }

  Widget _buildSelection(String title, Widget child, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.deepPurpleAccent),
              const SizedBox(width: 8),
              Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          child,
        ],
      ),
    );
  }

  Future<void> _confirmSchedule() async {
    if (_selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select a time!'), backgroundColor: Colors.red),
      );
      return;
    }

    final scheduleData = {
      "schedule": [
        {
          "date": _selectedDay.toUtc().toIso8601String(),
          "time": _selectedTime,
          "lesson": "Advanced JavaScript"
        }
      ]
    };

    try {
      final response = await http.put(
        Uri.parse('http://localhost:5000/api/match/update-schedule/67cfa8a127548c4566a8c9bd'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(scheduleData),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Schedule Updated Successfully!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update schedule!'), backgroundColor: Colors.red),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $error'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(LucideIcons.calendar, color: Colors.deepPurpleAccent),
                  const SizedBox(width: 8),
                  Text("Reschedule Your Classes", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 10),
              Divider(),
              _buildSelection('Select Date', TableCalendar(
                firstDay: DateTime.now(),
                lastDay: DateTime.now().add(Duration(days: 365)),
                focusedDay: _selectedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() => _selectedDay = selectedDay);
                },
              ), LucideIcons.calendarDays),
              _buildSelection('Select Time', _buildChoiceChips(_timeSlots, _selectedTime, (value) => _selectedTime = value), LucideIcons.clock),
              _buildSelection('Select Duration', _buildChoiceChips(_durations, _selectedDuration, (value) => _selectedDuration = value), LucideIcons.timer),
              _buildSelection('Select Location', _buildChoiceChips(_locations, _selectedLocation, (value) => _selectedLocation = value), LucideIcons.mapPin),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _confirmSchedule,
                  icon: Icon(LucideIcons.checkCircle, color: Colors.white),
                  label: Text('Confirm Schedule', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurpleAccent,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
