import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skillswap/models/user.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ExchangeSkillScreen extends StatefulWidget {
  final String userA;
  final String userB;
  final List<String> yourSkills;
  final List<String> theirSkills;
  final String duration;
  final String location;
  final String messagePreview;

  const ExchangeSkillScreen({
    Key? key,
    required this.userA,
    required this.userB,
    required this.yourSkills,
    required this.theirSkills,
    required this.duration,
    required this.location,
    required this.messagePreview, User? user,
  }) : super(key: key);

  @override
  _ExchangeSkillScreenState createState() => _ExchangeSkillScreenState();
}

class _ExchangeSkillScreenState extends State<ExchangeSkillScreen> {
  DateTime _selectedDay = DateTime.now();
  String _selectedTime = '';
  String _selectedDuration = '';
  String _selectedLocation = '';

  final List<String> _timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM',
    '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM'
  ];
  final List<String> _durations = ['30 min', '1 hour', '2 hours'];
  final List<String> _locations = ['Remote', 'Face-to-Face'];

  Future<void> _confirmSchedule() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? user_id = prefs.getString('user_id');

    if (_selectedTime.isEmpty || _selectedDuration.isEmpty || _selectedLocation.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select time, duration, and location.')),
      );
      return;
    }

    final url = Uri.parse('http://192.168.29.167:5000/api/match/request');
    final body = jsonEncode({     
      "userA":  user_id,
      "userB": widget.userB,
      "duration": _selectedDuration,
      "location": _selectedLocation,
      "message": widget.messagePreview,
      "date": _selectedDay.toIso8601String().split('T')[0],
      "time": _selectedTime,
    });

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Schedule Confirmed Successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to confirm schedule: ${response.body}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C5CE7),
        title: const Text('Exchange Skill', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSkillRow('Your Skills', widget.yourSkills),
              _buildSkillRow('Their Skills', widget.theirSkills),
              _buildMessagePreview(),
              const SizedBox(height: 24),
              _buildScheduleSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSkillRow(String title, List<String> skills) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: skills.map((skill) {
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.teal.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.teal, width: 2),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(FontAwesomeIcons.handshake, size: 16, color: Colors.teal),
                  const SizedBox(width: 8),
                  Text(skill, style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildMessagePreview() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Message Preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(widget.messagePreview, style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
   Widget _buildScheduleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSelection('Select Date', TableCalendar(
          firstDay: DateTime.now(),
          lastDay: DateTime.now().add(const Duration(days: 365)),
          focusedDay: _selectedDay,
          selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDay = selectedDay;
            });
          },
        )),
        _buildSelection('Select Time', _buildChoiceChips(_timeSlots, _selectedTime, (value) {
          setState(() {
            _selectedTime = value;
          });
        })),
        _buildSelection('Select Duration', _buildChoiceChips(_durations, _selectedDuration, (value) {
          setState(() {
            _selectedDuration = value;
          });
        })),
        _buildSelection('Select Location', _buildChoiceChips(_locations, _selectedLocation, (value) {
          setState(() {
            _selectedLocation = value;
          });
        })),
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _confirmSchedule,
            child: const Text('Confirm Schedule', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6C5CE7),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
        ),
      ],
    );
  }
   Widget _buildSelection(String title, Widget child) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        child,
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildChoiceChips(List<String> options, String selected, Function(String) onSelected) {
    return Wrap(
      spacing: 10,
      children: options.map((option) {
        return ChoiceChip(
          label: Text(option),
          selected: selected == option,
          onSelected: (selected) {
            if (selected) {
              onSelected(option);
            }
          },
        );
      }).toList(),
    );
  }
}



