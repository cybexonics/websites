import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class RequestPage extends StatefulWidget {
  const RequestPage({super.key});

  @override
  State<RequestPage> createState() => _RequestPageState();
}

class _RequestPageState extends State<RequestPage>
    with TickerProviderStateMixin {
  late TabController _mainTabController;
  late TabController _sendTabController;
  late TabController _receiveTabController;

  List<Map<String, dynamic>> sentPending = [];
  List<Map<String, dynamic>> sentAccepted = [];
  List<Map<String, dynamic>> sentRejected = [];

  List<Map<String, dynamic>> receivedPending = [];
  List<Map<String, dynamic>> receivedAccepted = [];
  List<Map<String, dynamic>> receivedRejected = [];

  String searchQuery = '';

  @override
  void initState() {
    fetchRequests();
    super.initState();
    _mainTabController = TabController(length: 2, vsync: this);
    _sendTabController = TabController(length: 3, vsync: this);
    _receiveTabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _mainTabController.dispose();
    _sendTabController.dispose();
    _receiveTabController.dispose();
    super.dispose();
  }

Future<void> fetchRequests() async {
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  String? user_id = prefs.getString('user_id');
  print('User_id: $user_id');

  // Fetch sent requests
  final sentResponse = await http
      .get(Uri.parse('http://192.168.29.167:5000/api/match/sent/$user_id'));
  if (sentResponse.statusCode == 200) {
    final sentData = json.decode(sentResponse.body);
    List<dynamic> sentRequests;
    if (sentData is Map<String, dynamic>) {
      sentRequests = sentData['sentRequests'] as List<dynamic>;
    } else if (sentData is List<dynamic>) {
      sentRequests = sentData;
    } else {
      print('Error: Unexpected data type for sent requests');
      return;
    }

    setState(() {
      sentPending = _filterRequests(sentRequests, 'pending', isSent: true);
      sentAccepted = _filterRequests(sentRequests, 'Accepted', isSent: true);
      sentRejected = _filterRequests(sentRequests, 'Rejected', isSent: true);
    });
  }

  // Fetch received requests
  final receivedResponse = await http
      .get(Uri.parse('http://192.168.29.167:5000/api/match/received/$user_id'));
  if (receivedResponse.statusCode == 200) {
    final receivedData = json.decode(receivedResponse.body);
    List<dynamic> receivedRequests;
    if (receivedData is Map<String, dynamic>) {
      receivedRequests = receivedData['receivedRequests'] as List<dynamic>;
    } else if (receivedData is List<dynamic>) {
      receivedRequests = receivedData;
    } else {
      print('Error: Unexpected data type for received requests');
      return;
    }

    setState(() {
      receivedPending = _filterRequests(receivedRequests, 'pending', isSent: false);
      receivedAccepted = _filterRequests(receivedRequests, 'accepted', isSent: false);
      receivedRejected = _filterRequests(receivedRequests, 'rejected', isSent: false);
    });
  }
}

List<Map<String, dynamic>> _filterRequests(List<dynamic> data, String status, {required bool isSent}) {
  return data
      .where((request) => request['status'] == status)
      .map((request) {
        final userField = isSent ? 'userB' : 'userA';
        final user = request[userField] is Map<String, dynamic> 
            ? request[userField] as Map<String, dynamic>
            : {'name': 'Unknown'};
        
        // Extract schedule information
        List<dynamic> scheduleList = request['schedule'] ?? [];
        
        return {
          'name': (user['name'] ?? 'Unknown').toString(),
          'status': (request['status'] ?? 'Unknown').toString(),
          'id': (request['_id'] ?? '').toString(),
          'duration': (request['duration'] ?? '').toString(),
          'location': (request['location'] ?? '').toString(),
          'message': (request['message'] ?? '').toString(),
          'schedule': scheduleList,
        };
      })
      .toList();
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text(
          'Manage Requests',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blueAccent,
        bottom: TabBar(
          controller: _mainTabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.send), text: 'Sent'),
            Tab(icon: Icon(Icons.move_to_inbox), text: 'Received'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _mainTabController,
        children: [
          _buildSubTabView(
            _sendTabController,
            sentPending,
            sentAccepted,
            sentRejected,
            isReceiveTab: false,
          ),
          _buildSubTabView(
            _receiveTabController,
            receivedPending,
            receivedAccepted,
            receivedRejected,
            isReceiveTab: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSubTabView(
    TabController controller,
    List<Map<String, dynamic>> pending,
    List<Map<String, dynamic>> accepted,
    List<Map<String, dynamic>> rejected, {
    required bool isReceiveTab,
  }) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search requests...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
            onChanged: (value) {
              setState(() {
                searchQuery = value.toLowerCase();
              });
            },
          ),
        ),
        Container(
          color: Colors.white,
          child: TabBar(
            controller: controller,
            labelColor: Colors.blueAccent,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blueAccent,
            tabs: const [
              Tab(text: 'Pending'),
              Tab(text: 'Accepted'),
              Tab(text: 'Rejected'),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: controller,
            children: [
              _buildRequestList(pending, 'pending', isReceiveTab),
              _buildRequestList(accepted, 'Accepted', isReceiveTab),
              _buildRequestList(rejected, 'Rejected', isReceiveTab),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRequestList(
    List<Map<String, dynamic>> requests, String status, bool isReceiveTab) {
  final filteredRequests = requests
      .where(
          (request) => request['name']!.toLowerCase().contains(searchQuery))
      .toList();

  return filteredRequests.isEmpty
      ? Center(
          child: Text(
            'No $status requests found.',
            style: const TextStyle(color: Colors.grey, fontSize: 16),
          ),
        )
      : ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: filteredRequests.length,
          itemBuilder: (context, index) {
            final request = filteredRequests[index];
            List<dynamic> scheduleList = request['schedule'] ?? [];
            
            return Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ExpansionTile(
                tilePadding: const EdgeInsets.all(12),
                leading: CircleAvatar(
                  backgroundColor: Colors.blueAccent,
                  child: Text(
                    request['name']![0],
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
                title: Text(
                  request['name']!,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Status: ${request['status']}',
                      style: TextStyle(
                        color: status == 'pending'
                            ? Colors.orange
                            : status == 'Accepted'
                                ? Colors.green
                                : Colors.red,
                      ),
                    ),
                    Text(
                      'Duration: ${request['duration']}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    Text(
                      'Location: ${request['location']}',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                trailing: (status == 'pending' && isReceiveTab)
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () => _updateRequestStatus(
                                requests, index, 'Accepted'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text('Accept'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () => _updateRequestStatus(
                                requests, index, 'Rejected'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.redAccent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text('Reject'),
                          ),
                        ],
                      )
                    : const Icon(Icons.keyboard_arrow_down),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Message:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(request['message'] ?? 'No message'),
                        const SizedBox(height: 16),
                        const Text(
                          'Schedule:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        scheduleList.isEmpty
                            ? const Text('No schedule information available')
                            : Column(
                                children: List.generate(
                                  scheduleList.length,
                                  (i) => _buildScheduleItem(scheduleList[i]),
                                ),
                              ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
}

Widget _buildScheduleItem(dynamic scheduleItem) {
  if (scheduleItem is! Map) return const SizedBox.shrink();
  
  // Format date
  String dateStr = scheduleItem['date'] ?? '';
  DateTime? date;
  try {
    date = DateTime.parse(dateStr);
  } catch (_) {}
  
  String formattedDate = date != null 
      ? '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}'
      : dateStr;
  
  return Card(
    margin: const EdgeInsets.only(bottom: 8),
    color: Colors.grey[50],
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Lesson: ${scheduleItem['lesson'] ?? 'Not specified'}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text('Date: $formattedDate'),
          Text('Time: ${scheduleItem['time'] ?? 'Not specified'}'),
          Text('Duration: ${scheduleItem['duration'] ?? 'Not specified'}'),
          Text('Location: ${scheduleItem['location'] ?? 'Not specified'}'),
          if (scheduleItem['message'] != null) ...[
            const SizedBox(height: 4),
            Text('Note: ${scheduleItem['message']}'),
          ],
        ],
      ),
    ),
  );
}

Future<void> _updateRequestStatus(
    List<Map<String, dynamic>> list, int index, String status) async {
  final request = list[index];
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  String? userId = prefs.getString('user_id');
  final requestId = request['id'];

  print("User ID: $userId");
  print("Request ID: $requestId");

  if (userId == null || requestId == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Failed to update request status: Missing user or request ID.'),
        backgroundColor: Colors.red,
      ),
    );
    return;
  }

  // Determine the API endpoint based on the status
  String apiUrl = status == 'Accepted'
      ? 'http://localhost:5000/api/match/accept/$requestId'
      : 'http://localhost:5000/api/match/reject/$requestId';

  print('Hitting API: $apiUrl');

  try {
    final response = await http.post(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      setState(() {
        list.removeAt(index);

        if (status == 'Accepted') {
          receivedAccepted.add({'name': request['name']!, 'status': 'Accepted', 'id': requestId});
        } else if (status == 'Rejected') {
          receivedRejected.add({'name': request['name']!, 'status': 'Rejected', 'id': requestId});
        }
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Request marked as $status.'),
          backgroundColor: status == 'Accepted' ? Colors.green : Colors.red,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to update request status.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  } catch (error) {
    print("Error: $error");
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('An error occurred while updating request status.'),
        backgroundColor: Colors.red,
      ),
    );
  }
}


    }

