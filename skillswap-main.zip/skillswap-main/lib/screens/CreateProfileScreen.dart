import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:location/location.dart' as loc; // Alias for location package
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';
import 'package:skillswap/screens/skill_match_screen.dart';
import '../widgets/widgets.dart';
import '../styles/style.dart';
import 'package:flutter/foundation.dart';


class CreateProfileScreen extends StatefulWidget {
  final String token; 
  final String userId; // Directly take userId as an argument

  const CreateProfileScreen({Key? key, required this.token, required this.userId}) 
      : super(key: key);

  @override
  _CreateProfileScreenState createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends State<CreateProfileScreen> {
  final List<String> _selectedTeachSkills = [];
  final List<String> _selectedLearnSkills = [];
  final TextEditingController _locationController = TextEditingController();
  bool _weekdayMornings = false;
  bool _weekdayEvenings = false;
  bool _weekendMornings = false;
  bool _weekendEvenings = false;
  File? _profileImage;
  File? _uploadedFile;
  final ImagePicker _picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C5CE7),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Create Your Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ProfileImagePicker(
              profileImage: _profileImage,
              onPickImage: _pickProfileImage,
            ),
            const SizedBox(height: 24),
            _buildSection('Skills to Teach', SkillTagWidget(
              skills: _selectedTeachSkills,
              onRemoveSkill: (skill) {
                setState(() => _selectedTeachSkills.remove(skill));
              },
              onAddSkill: () => _showAddSkillDialog(_selectedTeachSkills),
            )),
            _buildSection('Skills to Learn', SkillTagWidget(
              skills: _selectedLearnSkills,
              onRemoveSkill: (skill) {
                setState(() => _selectedLearnSkills.remove(skill));
              },
              onAddSkill: () => _showAddSkillDialog(_selectedLearnSkills),
            )),
            _buildSection('Location', LocationTextField(
              locationController: _locationController,
              onGetLocation: _getLocation,
            )),
            _buildSection('Availability', Column(
              children: [
                CheckboxListTile(
                  title: const Text('Weekday Mornings'),
                  value: _weekdayMornings,
                  onChanged: (bool? value) {
                    setState(() {
                      _weekdayMornings = value ?? false;
                    });
                  },
                ),
                CheckboxListTile(
                  title: const Text('Weekday Evenings'),
                  value: _weekdayEvenings,
                  onChanged: (bool? value) {
                    setState(() {
                      _weekdayEvenings = value ?? false;
                    });
                  },
                ),
                CheckboxListTile(
                  title: const Text('Weekend Mornings'),
                  value: _weekendMornings,
                  onChanged: (bool? value) {
                    setState(() {
                      _weekendMornings = value ?? false;
                    });
                  },
                ),
                CheckboxListTile(
                  title: const Text('Weekend Evenings'),
                  value: _weekendEvenings,
                  onChanged: (bool? value) {
                    setState(() {
                      _weekendEvenings = value ?? false;
                    });
                  },
                ),
              ],
            )),
            _buildSection('Certifications & Portfolio', UploadAreaWidget(
              onPickFile: _pickFile,
              uploadedFile: _uploadedFile,
            )),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveProfile,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C5CE7),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Save Profile',
                  style: AppStyles.buttonText.copyWith(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

Future<void> _pickProfileImage() async {
  final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
  if (pickedFile != null) {
    final bytes = await pickedFile.readAsBytes();
    setState(() {
      _profileImage = File(pickedFile.path); // For mobile
      // _profileImageBytes = bytes;  // Use this for Flutter Web
    });
  }
}


Future<void> _getLocation() async {
  loc.Location location = loc.Location(); // Use alias
  bool serviceEnabled;
  loc.PermissionStatus permissionGranted;

  serviceEnabled = await location.serviceEnabled();
  if (!serviceEnabled) {
    serviceEnabled = await location.requestService();
    if (!serviceEnabled) {
      print('Location service is not enabled');
      return;
    }
  }

  permissionGranted = await location.hasPermission();
  if (permissionGranted == loc.PermissionStatus.denied) {
    permissionGranted = await location.requestPermission();
    if (permissionGranted != loc.PermissionStatus.granted) {
      print('Location permission denied');
      return;
    }
  }

  // Get the user's location
  loc.LocationData locationData = await location.getLocation();

  try {
    List<Placemark> placemarks = await placemarkFromCoordinates(
      locationData.latitude!,
      locationData.longitude!,
    );

    if (placemarks.isNotEmpty) {
      Placemark place = placemarks[0];

      setState(() {
        _locationController.text = place.locality ?? 'Unknown City';
      });
    }
  } catch (e) {
    print('Error fetching city name: $e');
  }
}

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() => _uploadedFile = File(result.files.single.path!));
    }
  }

// Future<String?> _fetchUserId() async {
//   const String profileUrl = 'http://192.168.29.167:5000/api/users/me'; // API to get logged-in user details

//   final response = await http.get(
//     Uri.parse(profileUrl),
//     headers: {
//       'Authorization': 'Bearer ${widget.token}', // Pass token in headers
//       'Content-Type': 'application/json',
//     },
//   );

//   if (response.statusCode == 200) {
//     final Map<String, dynamic> userData = jsonDecode(response.body);
//     return userData['_id']; // Assuming backend returns user ID as '_id'
//   } else {
//     print('Failed to fetch user ID: ${response.reasonPhrase}');
//     return null;
//   }
// }

Future<void> _saveProfile() async {
  final String url = 'http://192.168.29.167:5000/api/users/${widget.userId}'; // Use userId directly
  var request = http.MultipartRequest('PUT', Uri.parse(url));
  request.headers['Authorization'] = 'Bearer ${widget.token}'; // Auth header

  if (_profileImage != null) {
    List<int> imageBytes = await _profileImage!.readAsBytes();
    request.files.add(
      http.MultipartFile.fromBytes(
        'profileImage',
        imageBytes,
        filename: 'profile_image.jpg',
      ),
    );
  }

  request.fields['location'] = _locationController.text;
  // Send skills as JSON arrays instead of comma-separated strings
  request.fields['skillsTeach'] = jsonEncode(_selectedTeachSkills);
  request.fields['skillsLearn'] = jsonEncode(_selectedLearnSkills);

  var response = await request.send();

  if (response.statusCode == 200) {
    print('Profile updated successfully');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SkillMatchScreen(
          userProfile: {
            'image': _profileImage,
            'location': _locationController.text,
            'teachSkills': _selectedTeachSkills,
            'learnSkills': _selectedLearnSkills,
          }, loggedInUserId: '',
        ),
      ),
    );
  } else {
    print('Failed to update profile: ${response.reasonPhrase}');
  }
}

  Widget _buildSection(String title, Widget content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: AppStyles.sectionTitle),
          const SizedBox(height: 8),
          content,
        ],
      ),
    );
  }

  void _showAddSkillDialog(List<String> skills) {
    TextEditingController skillController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add a Skill'),
        content: TextField(
          controller: skillController,
          decoration: const InputDecoration(hintText: 'Enter skill'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (skillController.text.isNotEmpty) {
                setState(() => skills.add(skillController.text));
              }
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }
}

