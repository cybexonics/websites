import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:skillswap/widgets/signup_widget.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();

  String? _name;
  String? _email;
  String? _password;
  bool _isPasswordVisible = false;
  bool _isLoading = false;
  String? _confirmPassword;

Future<void> _signUp() async {
  if (!_formKey.currentState!.validate()) return;

  _formKey.currentState!.save();

  setState(() {
    _isLoading = true;
  });

  try {
    var response = await http.post(
      Uri.parse('http://192.168.29.167:5000/api/auth/register'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "name": _name,
        "email": _email,
        "password": _password,
        "confirmPassword": _confirmPassword,
      }),
    );

    var responseBody = jsonDecode(response.body);

    if (response.statusCode == 201) {
      // Show popup dialog
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("Success"),
          content: const Text("Registration successful! Please log in."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog
                Navigator.pushReplacementNamed(context, '/login'); // Navigate to login
              },
              child: const Text("OK"),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${responseBody['error']}")),
      );
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Error: ${e.toString()}")),
    );
  }

  setState(() {
    _isLoading = false;
  });
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                buildHeaderIcon(),
                buildTitle(),
                buildTextField(
                  labelText: 'Full Name',
                  hintText: 'Enter your full name',
                  onSaved: (value) => _name = value,
                ),
                buildTextField(
                  labelText: 'Email Address',
                  hintText: 'Enter your email',
                  keyboardType: TextInputType.emailAddress,
                  onSaved: (value) => _email = value,
                ),
                buildPasswordField(
                  labelText: 'Password',
                  hintText: 'Enter your password',
                  isPasswordVisible: _isPasswordVisible,
                  toggleVisibility: () =>
                      setState(() => _isPasswordVisible = !_isPasswordVisible),
                  onChanged: (value) =>
                      setState(() => _password = value), // Fix: Update state
                  onSaved: (value) => _password = value, // Ensure it's saved
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter a password";
                    } else if (value.length < 6) {
                      return "Password must be at least 6 characters long";
                    }
                    return null;
                  },
                ),
                buildPasswordField(
                  labelText: 'Confirm Password',
                  hintText: 'Re-enter your password',
                  isPasswordVisible: _isPasswordVisible,
                  toggleVisibility: () =>
                      setState(() => _isPasswordVisible = !_isPasswordVisible),
                  onChanged: (value) => setState(
                      () => _confirmPassword = value), // Fix: Update state
                  onSaved: (value) =>
                      _confirmPassword = value, // Ensure it's saved
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please confirm your password";
                    } else if (_password != null && value != _password) {
                      return "Passwords do not match";
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                _isLoading
                    ? const CircularProgressIndicator()
                    : buildSignUpButton(_signUp),
                buildLoginOption(context),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
