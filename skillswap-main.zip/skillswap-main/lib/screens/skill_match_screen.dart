import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skillswap/ChatScreen.dart';
import 'package:skillswap/ChatlistScreen.dart';
import 'package:skillswap/RequestSkillExchangeScreen.dart';
import 'package:skillswap/request_page.dart';
import 'package:skillswap/skill_swap_premium.dart';
import 'dart:convert';

import 'package:skillswap/styles/style.dart';
import 'package:skillswap/styles/user_profile_card.dart';
import 'package:skillswap/editprofile.dart';
import 'package:skillswap/skill_reviews.dart';
import 'package:skillswap/ClassSchedule.dart';
import 'package:skillswap/admindashboard.dart';

class SkillMatchScreen extends StatefulWidget {
  final String loggedInUserId;
  const SkillMatchScreen({
    super.key,
    required this.loggedInUserId,
    required Map<String, Object?> userProfile,
  });

  @override
  _SkillMatchScreenState createState() => _SkillMatchScreenState();
}

class _SkillMatchScreenState extends State<SkillMatchScreen>
    with SingleTickerProviderStateMixin {
  List<dynamic> users = [];
  bool isLoading = true;
  late TabController _tabController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    fetchUsers();
    _tabController = TabController(length: 5, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentIndex = _tabController.index;
      });
      _handleTabChange(_currentIndex);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _handleTabChange(int index) {
    switch (index) {
      case 0: // Home - already on this screen
        break;
      case 1: // Schedules
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) =>  ClassScheduleApp ()),
        );
        break;
      case 2: // Reviews
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => NewReviewsScreen()),
        );
        break;
      case 3: // Chats
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AdminDashboard()),
        );
        break;
      case 4: // Profile
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => EditProfileScreen(
                    userId: '',
                  )),
        );
        break;
     case 5: // Premium
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => PremiumPage()),
  );
  break;

    }
  }

  Future<void> fetchUsers() async {
    try {
      final response =
          await http.get(Uri.parse('http://192.168.29.167:5000/api/users'));

      if (response.statusCode == 200) {
        List<dynamic> allUsers = json.decode(response.body);

        // Filter out the logged-in user
        List<dynamic> filteredUsers = allUsers
            .where((user) => user['_id'] != widget.loggedInUserId)
            .toList();

        setState(() {
          users = filteredUsers;
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        throw Exception('Failed to load users');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      debugPrint('Error fetching users: $e');
    }
  }

  void _showPopupMenu(BuildContext context) async {
    await showMenu(
      context: context,
      position: const RelativeRect.fromLTRB(100, 50, 0, 0),
      items: [
        PopupMenuItem(
          value: 'edit_profile',
          child: ListTile(
            leading: const Icon(Icons.edit, color: Colors.blue),
            title: const Text('Edit Profile'),
          ),
        ),
        PopupMenuItem(
          value: 'home',
          child: ListTile(
            leading: const Icon(Icons.home, color: Colors.green),
            title: const Text('Home'),
          ),
        ),
        PopupMenuItem(
          value: 'schedules',
          child: ListTile(
            leading: const Icon(Icons.calendar_today, color: Colors.orange),
            title: const Text('Schedules'),
          ),
        ),
        PopupMenuItem(
          value: 'requests',
          child: ListTile(
            leading: const Icon(Icons.request_page, color: Colors.purple),
            title: const Text('Requests'),
          ),
        ),
        PopupMenuItem(
          value: 'reviews',
          child: ListTile(
            leading: const Icon(Icons.star, color: Colors.amber),
            title: const Text('Reviews'),
          ),
        ),
        PopupMenuItem(
          value: 'chats',
          child: ListTile(
            leading: const Icon(Icons.chat, color: Colors.teal),
            title: const Text('Chats'),
          ),
        ),
        PopupMenuItem(
          value: 'AdminDashboard',
          child: ListTile(
            leading: const Icon(Icons.chat, color: Colors.teal),
            title: const Text('Admin Dashboard'),
          ),
        ),
         PopupMenuItem(
          value: 'premium',
          child: ListTile(
            leading: const Icon(Icons.chat, color: Colors.teal),
            title: const Text('Premium'),
          ),
        ),
      ],
      elevation: 8.0,
    ).then((value) async {
      if (value != null) {
        switch (value) {
          case 'edit_profile':
            final SharedPreferences prefs =
                await SharedPreferences.getInstance();
            String? user_id = prefs.getString('user_id');
            print('User_id: $user_id');
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => EditProfileScreen(
                        userId: '$user_id',
                      )),
            );
            break;
          case 'home':
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SkillMatchScreen(
                  loggedInUserId: widget.loggedInUserId,
                  userProfile: {},
                ),
              ),
            );
            break;
          case 'schedules':
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) =>  ClassScheduleApp ()),
            );
            break;
          case 'requests':
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RequestPage()),
            );
            break;
          case 'reviews':
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => NewReviewsScreen()),
            );
            break;
          // case 'chats':
          //   Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) => ChatDetailScreen(
          //               contact: ChatContact(
          //                 name: "Sanket",
          //                 status: "online",
          //                 imageUrl: "imageUrl",
          //                 lastMessage: "lastMessage",
          //                 lastMessageTime:
          //                     DateTime.now(), // Assigning the current time
          //                 isOnline: true, // Assuming the user is online
          //                 isTyping: false, // Assuming the user is not typing
          //                 unreadCount: 3, // Example unread message count
          //               ),
          //             )),
          //   );
          //   break;

          case 'chats':
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ChatListScreen(
                        contact: ChatContact(
                          name: "Sanket",
                          status: "online",
                          imageUrl: "imageUrl",
                          lastMessage: "lastMessage",
                          lastMessageTime:
                              DateTime.now(), // Assigning the current time
                          isOnline: true, // Assuming the user is online
                          isTyping: false, // Assuming the user is not typing
                          unreadCount: 3, // Example unread message count
                        ),
                      )),
            );
            break;

          case 'AdminDashboard':
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AdminDashboard()),
            );
            break;
          case 'premium':
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => PremiumPage()),
  );
  break;

        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // AppBar-like header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.logout, color: Colors.red),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  Text(
                    'Find Your Skill Match',
                    style: AppStyles.headingText,
                  ),
                  IconButton(
                    icon: const Icon(Icons.more_vert, color: Colors.black),
                    onPressed: () => _showPopupMenu(context),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Search bar
              TextField(
                decoration: InputDecoration(
                  hintText: 'Search skills or people...',
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  filled: true,
                  fillColor: Colors.grey[100],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // User list

              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : ListView.builder(
                        itemCount: users.length,
                        itemBuilder: (context, index) {
                          var user = users[index];
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      RequestSkillExchangeScreen(
                                    userId: user['_id'],
                                  ),
                                ),
                              );
                            },
                            child: UserProfileCard(
                              name: user['name'],
                              location: user['location'] ?? 'Unknown',
                              skillsToTeach:
                                  List<String>.from(user['skillsTeach'] ?? []),
                              skillsToLearn:
                                  List<String>.from(user['skillsLearn'] ?? []),
                              availability:
                                  user['availability'] ?? 'Not Available',
                              imageUrl: user['profilePicture'] ??
                                  'https://example.com/default.png',
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Material(
        color: Colors.white,
        child: TabBar(
          controller: _tabController,
          indicatorColor: Colors.blue,
          labelColor: Colors.blue,
          unselectedLabelColor: Colors.grey,
          tabs: const [
            Tab(
              icon: Icon(Icons.home),
              text: 'Home',
            ),
            Tab(
              icon: Icon(Icons.schedule),
              text: 'Schedules',
            ),
            Tab(
              icon: Icon(Icons.star),
              text: 'Reviews',
            ),
            Tab(
              icon: Icon(Icons.chat),
              text: 'Chats',
            ),
            Tab(
              icon: Icon(Icons.person),
              text: 'Profile',
            ),
            Tab(
              icon: Icon(Icons.person),
              text: 'premium',
            ),
          ],
        ),
      ),
    );
  }
}

class ClassScheduleApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SkillSwap',
      theme: ThemeData(
        primaryColor: Color(0xFF6C5CE7),
        scaffoldBackgroundColor: Color(0xFFF5F7FA),
        fontFamily: 'Poppins',
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF6C5CE7),
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF6C5CE7),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      home: ClassSchedulePage(),
    );
  }
}
