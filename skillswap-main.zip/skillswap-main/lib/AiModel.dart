import 'package:flutter/material.dart';

class AiModelPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "AI Model Dashboard",
          style: TextStyle(color: Colors.blue.shade900, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: Colors.blue.shade900),
      ),
      body: AiModelUpdatesContent(),
    );
  }
}

class AiModelUpdatesContent extends StatelessWidget {
  final Map<String, dynamic> aiModelMetrics = {
    'modelVersion': 'v3.0.5',
    'accuracy': 94.2,
    'updateDate': '2025-03-01',
    'trainingDataSize': 750000,
    'processingTime': 1.8,
  };

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(Icons.smart_toy, size: 80, color: Colors.blue.shade900),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(child: _buildModelStatsCard()),
              SizedBox(width: 20),
              Expanded(child: _buildUpdatesCard()),
            ],
          ),
          SizedBox(height: 20),
          _buildProgressCard("Accuracy", aiModelMetrics['accuracy'].toDouble(), Colors.blue.shade900),
        ],
      ),
    );
  }

  Widget _buildModelStatsCard() {
    return _buildInfoCard([
      _buildInfoRow("Model Version", aiModelMetrics['modelVersion']),
      _buildInfoRow("Last Updated", aiModelMetrics['updateDate']),
      _buildInfoRow("Data Size", "${aiModelMetrics['trainingDataSize']} entries"),
    ], "AI Model Stats", Colors.blue.shade900);
  }

  Widget _buildUpdatesCard() {
    return _buildInfoCard([
      _buildInfoRow("Speed Boost", "Optimized inference time"),
      _buildInfoRow("Security Fix", "Improved data validation"),
      _buildInfoRow("Better AI", "Trained on 25% more data"),
    ], "Latest Updates", Colors.blue.shade700);
  }

  Widget _buildInfoCard(List<Widget> children, String title, Color color) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: 2),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 12, spreadRadius: 2)
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: color)),
          SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(color: Colors.grey.shade800, fontSize: 14, fontWeight: FontWeight.w500)),
          Text(value, style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildProgressCard(String title, double value, Color color) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: 2),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 12, spreadRadius: 2)
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: color)),
          SizedBox(height: 10),
          _buildProgressBar(value, color),
        ],
      ),
    );
  }

  Widget _buildProgressBar(double value, Color color) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: LinearProgressIndicator(
        minHeight: 12,
        value: value / 100,
        backgroundColor: Colors.grey[300],
        valueColor: AlwaysStoppedAnimation(color),
      ),
    );
  }
}
