import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class MonetizationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Monetization & Revenue", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: const Color.fromARGB(255, 10, 10, 10))),
        backgroundColor: const Color.fromARGB(255, 246, 244, 244),
        elevation: 0,
      ),
      body: MonetizationContent(),
      backgroundColor: Colors.white,
    );
  }
}

class MonetizationContent extends StatelessWidget {
  final List<Map<String, dynamic>> premiumPlans = [
    {'name': 'Basic Plan', 'price': '\$9.99/month', 'features': ['Limited Access', 'Ads Supported']},
    {'name': 'Pro Plan', 'price': '\$19.99/month', 'features': ['Unlimited Access', 'No Ads', 'Priority Support']},
    {'name': 'Enterprise', 'price': '\$49.99/month', 'features': ['Custom Features', 'Dedicated Support', 'Advanced Analytics']},
  ];

  final List<Map<String, dynamic>> subscribers = [
    {'name': 'Alice', 'plan': 'Pro Plan', 'status': 'Active'},
    {'name': 'Bob', 'plan': 'Basic Plan', 'status': 'Active'},
    {'name': 'Charlie', 'plan': 'Enterprise', 'status': 'Active'},
    {'name': 'David', 'plan': 'Pro Plan', 'status': 'Expired'},
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Revenue Overview
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            color: Colors.blue,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text("Total Revenue", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                  SizedBox(height: 10),
                  Text("\$15,320", style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
                  SizedBox(height: 10),
                  Text("Total Subscribers: 120", style: TextStyle(fontSize: 16, color: Colors.white70)),
                ],
              ),
            ),
          ),

          SizedBox(height: 20),

          // Subscription Plans
          Text("Premium Plans", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue)),
          SizedBox(height: 10),
          Column(
            children: premiumPlans.map((plan) {
              return Card(
                margin: EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 3,
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(plan['name'], style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue)),
                      SizedBox(height: 5),
                      Text(plan['price'], style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue[900])),
                      SizedBox(height: 5),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: plan['features'].map<Widget>((feature) {
                          return Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.blue, size: 16),
                              SizedBox(width: 5),
                              Text(feature, style: TextStyle(color: Colors.black87)),
                            ],
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),

          SizedBox(height: 20),

          // Active Subscribers
          Text("Subscribers", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue)),
          SizedBox(height: 10),
          Column(
            children: subscribers.map((user) {
              return Card(
                margin: EdgeInsets.symmetric(vertical: 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                color: Colors.white,
                child: ListTile(
                  leading: Icon(FontAwesomeIcons.user, color: Colors.blue),
                  title: Text(user['name'], style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black)),
                  subtitle: Text(user['plan'], style: TextStyle(color: Colors.black54)),
                  trailing: Text(
                    user['status'], 
                    style: TextStyle(color: user['status'] == 'Active' ? Colors.blue : Colors.red),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
