import 'package:flutter/material.dart';

class CommunityPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Community Moderation", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: const Color.fromARGB(255, 9, 9, 9))),
        backgroundColor: const Color.fromARGB(255, 255, 255, 255),
        elevation: 0,
      ),
      body: CommunityContent(),
      backgroundColor: Colors.white,
    );
  }
}

class CommunityContent extends StatelessWidget {
  final List<Map<String, dynamic>> forumThreads = [
    {
      'title': 'Flutter vs React Native',
      'author': 'User1',
      'date': '2025-02-10',
      'posts': [
        {'author': 'User1', 'content': 'What do you think about Flutter vs React Native?', 'flagged': false, 'flagReason': ''},
        {'author': 'User2', 'content': 'Flutter is the best!', 'flagged': false, 'flagReason': ''},
        {'author': 'User3', 'content': 'React Native has better community support.', 'flagged': true, 'flagReason': 'Inappropriate language'},
      ]
    },
    {
      'title': 'Best UI Design Practices',
      'author': 'User4',
      'date': '2025-02-12',
      'posts': [
        {'author': 'User4', 'content': 'What are the best practices for UI design in mobile apps?', 'flagged': false, 'flagReason': ''},
        {'author': 'User5', 'content': 'Always prioritize user experience!', 'flagged': false, 'flagReason': ''},
      ]
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Forum Discussions",
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.blue),
          ),
          SizedBox(height: 16),
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: forumThreads.length,
            itemBuilder: (context, index) {
              return Card(
                margin: EdgeInsets.symmetric(vertical: 8),
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 3,
                shadowColor: Colors.blue[200],
                child: ExpansionTile(
                  title: Text(
                    forumThreads[index]['title'],
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                  subtitle: Text(
                    "Started by: ${forumThreads[index]['author']} on ${forumThreads[index]['date']}",
                    style: TextStyle(fontSize: 14, color: Colors.blue[700]),
                  ),
                  children: forumThreads[index]['posts'].map<Widget>((post) {
                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                      color: post['flagged'] ? Colors.blue[100] : Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 2,
                      shadowColor: Colors.blue[100],
                      child: ListTile(
                        contentPadding: EdgeInsets.all(16),
                        leading: CircleAvatar(
                          backgroundColor: Colors.blue,
                          child: Icon(Icons.person, color: Colors.white),
                        ),
                        title: Text(
                          post['author'],
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(post['content'], style: TextStyle(color: Colors.black87)),
                            if (post['flagged'])
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  'Flagged Reason: ${post['flagReason']}',
                                  style: TextStyle(color: Colors.red, fontStyle: FontStyle.italic),
                                ),
                              ),
                          ],
                        ),
                        trailing: post['flagged']
                            ? PopupMenuButton<String>(
                                onSelected: (value) {
                                  if (value == 'Delete') {
                                    // Handle delete logic
                                  } else if (value == 'Resolve') {
                                    // Handle resolve logic
                                  }
                                },
                                itemBuilder: (BuildContext context) {
                                  return {'Delete', 'Resolve'}
                                      .map((String choice) {
                                    return PopupMenuItem<String>(
                                      value: choice,
                                      child: Text(choice),
                                    );
                                  }).toList();
                                },
                              )
                            : null,
                      ),
                    );
                  }).toList(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
