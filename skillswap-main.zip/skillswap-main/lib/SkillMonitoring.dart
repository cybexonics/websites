import 'package:flutter/material.dart';

class SkillExchange {
  final String userName;
  final String skill;
  final String status;

  SkillExchange({required this.userName, required this.skill, required this.status});
}

class SkillMonitoringPage extends StatelessWidget {
  final List<SkillExchange> exchanges = [
    SkillExchange(userName: "John Doe", skill: "Flutter Development", status: "Ongoing"),
    SkillExchange(userName: "Jane Smith", skill: "Graphic Design", status: "Completed"),
    SkillExchange(userName: "Samuel Adams", skill: "Python Programming", status: "Pending"),
    SkillExchange(userName: "Emma Watson", skill: "UI/UX Design", status: "Ongoing"),
    SkillExchange(userName: "Michael Johnson", skill: "Data Science", status: "Completed"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Skill Exchange Monitoring",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        backgroundColor: const Color.fromARGB(255, 251, 251, 251),
      
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: exchanges.length,
          itemBuilder: (context, index) {
            final exchange = exchanges[index];
            return SkillExchangeCard(exchange: exchange);
          },
        ),
      ),
    );
  }
}

class SkillExchangeCard extends StatelessWidget {
  final SkillExchange exchange;

  const SkillExchangeCard({required this.exchange, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      color: const Color.fromARGB(255, 249, 249, 250),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.white,
          child: const Icon(Icons.person, color: Colors.black),
        ),
        title: Text(
          exchange.userName,
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        subtitle: Text(
          "Skill: ${exchange.skill}\nStatus: ${exchange.status}",
          style: const TextStyle(color: Colors.black),
        ),
        trailing: Icon(
          Icons.circle,
          color: Colors.black,
          size: 12,
        ),
        onTap: () => _showUserDetails(context, exchange),
      ),
    );
  }

  void _showUserDetails(BuildContext context, SkillExchange exchange) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        backgroundColor: const Color.fromARGB(255, 239, 240, 240),
        title: const Text("User Details", style: TextStyle(color: Colors.black)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("User: ${exchange.userName}", style: const TextStyle(color: Colors.black)),
            Text("Skill: ${exchange.skill}", style: const TextStyle(color: Colors.black)),
            Text("Status: ${exchange.status}", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Close", style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }
}
