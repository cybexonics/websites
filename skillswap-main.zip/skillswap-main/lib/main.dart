import 'package:flutter/material.dart';
import 'package:skillswap/ClassSchedule.dart';
import 'package:skillswap/screens/CreateProfileScreen.dart';
import 'package:skillswap/screens/login_screen.dart';
import 'package:skillswap/screens/signup_screen.dart';
import 'package:skillswap/screens/skill_match_screen.dart';
import 'splash_page.dart';
import 'exchange_skill.dart';
import 'notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
 
  await NotificationService.initialize();

  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
       home: ClassSchedulePage(),
      title: 'SkillSwap',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/splash',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/splash':
            return MaterialPageRoute(builder: (_) => SplashPage());

          case '/signup':
            return MaterialPageRoute(builder: (_) => const SignUpScreen());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginScreen());

          case '/createProfile':
            if (settings.arguments is Map<String, dynamic>) {
              final args = settings.arguments as Map<String, dynamic>;
              final token = args['token'] as String?;
              final userId = args['userId'] as String?;
              if (token != null && userId != null) {
                return MaterialPageRoute(
                  builder: (_) => CreateProfileScreen(token: token, userId: userId),
                );
              }
            }
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Center(child: Text('Error: Token or User ID not provided'))),
            );

          case '/exchangeSkill':
            return MaterialPageRoute(
              builder: (_) => const ExchangeSkillScreen(
                yourSkills: ['Graphic Design'],
                theirSkills: ['Cooking'],
                duration: '1 hour',
                location: 'Remote', 
                messagePreview: 'Looking forward to exchanging skills!', userA: '', userB: '',
              ),
            );

          case '/skillMatching':
            return MaterialPageRoute(
              builder: (_) => const SkillMatchScreen(userProfile: {}, loggedInUserId: ''),
            );

          case '/classSchedule':
            return MaterialPageRoute(builder: (_) => ClassSchedulePage());

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Center(child: Text('Page Not Found'))),
            );
        }
      },
    );
  }
}



