import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:skillswap/Reschedule.dart';

import 'package:skillswap/screens/skill_match_screen.dart';

class ClassSchedulePage extends StatefulWidget {
  @override
  _ClassSchedulePageState createState() => _ClassSchedulePageState();
}

class _ClassSchedulePageState extends State<ClassSchedulePage> {
  List<Map<String, String>> schedule = [];
  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    fetchSchedule();
  }

 Future<void> fetchSchedule() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('user_id');

    if (userId == null) {
      setState(() {
        errorMessage = 'User ID not found. Please log in again.';
        isLoading = false;
      });
      return;
    }

    print('Schedule User_id: $userId');

    final url = Uri.parse('http://192.168.29.167:5000/api/match/schedules/$userId');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        // Parse the response properly based on its structure
        final dynamic decodedData = json.decode(response.body);
        
        // Check if the response has a schedules field
        if (decodedData is Map && decodedData.containsKey('schedules')) {
          final List<dynamic> scheduleData = decodedData['schedules'] as List<dynamic>;
          
          setState(() {
            schedule = scheduleData.map((item) {
              return {
                'date': item['date']?.toString() ?? '',
                'time': item['time']?.toString() ?? '',
                'lesson': item['lesson']?.toString() ?? '',
                'id': item['_id']?.toString() ?? '',
              };
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = 'Unexpected response format';
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = 'Failed to load schedule: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      print('Error fetching schedule: $e');
      setState(() {
        errorMessage = 'Error connecting to server';
        isLoading = false;
      });
    }
  }

  String formatDate(String dateStr) {
    try {
      final DateTime date = DateTime.parse(dateStr);
      return DateFormat('EEEE, MMMM d, yyyy').format(date);
    } catch (e) {
      return dateStr;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'My Class Schedule',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xFF6C5CE7),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SkillMatchScreen(userProfile: {}, loggedInUserId: ''),
              ),
            );
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: () {
              setState(() {
                isLoading = true;
                errorMessage = '';
              });
              fetchSchedule();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            height: 80,
            decoration: BoxDecoration(
              color: Color(0xFF6C5CE7),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Center(
              child: Text(
                'Your upcoming learning sessions',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6C5CE7)),
                    ),
                  )
                : errorMessage.isNotEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.error_outline,
                              size: 60,
                              color: Colors.red[300],
                            ),
                            SizedBox(height: 16),
                            Text(
                              errorMessage,
                              style: TextStyle(fontSize: 16),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 24),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  isLoading = true;
                                  errorMessage = '';
                                });
                                fetchSchedule();
                              },
                              child: Text('Try Again'),
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Color(0xFF6C5CE7),
                                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                              ),
                            ),
                          ],
                        ),
                      )
                    : schedule.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  'assets/empty_calendar.png',
                                  height: 120,
                                  width: 120,
                                ),
                                SizedBox(height: 16),
                                Text(
                                  'No classes scheduled yet',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  'Check back later or book a new session',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16.0),
                            child: ListView.builder(
                              padding: EdgeInsets.only(top: 16.0, bottom: 24.0),
                              itemCount: schedule.length,
                              itemBuilder: (context, index) {
                                final item = schedule[index];
                                return ScheduleCard(
                                  date: item['date'] ?? '',
                                  time: item['time'] ?? '',
                                  lesson: item['lesson'] ?? '',
                                  id: item['id'] ?? '',
                                );
                              },
                            ),
                          ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add functionality to book a new class
        },
        backgroundColor: Color(0xFF6C5CE7),
        child: Icon(Icons.add),
      ),
    );
  }
}

class ScheduleCard extends StatelessWidget {
  final String date;
  final String time;
  final String lesson;
  final String id;

  const ScheduleCard({
    Key? key,
    required this.date,
    required this.time,
    required this.lesson,
    this.id = '',
  }) : super(key: key);

  String formatDate(String dateStr) {
    try {
      final DateTime date = DateTime.parse(dateStr);
      return DateFormat('EEEE, MMMM d').format(date);
    } catch (e) {
      return dateStr;
    }
  }

  Color getRandomColor() {
    final List<Color> colors = [
      Color(0xFFFF9FF3), // Pink
      Color(0xFFFECA57), // Yellow
      Color(0xFF54A0FF), // Blue
      Color(0xFF1DD1A1), // Green
      Color(0xFFFF6B6B), // Red
    ];
    
    // Use a simple hash of the skill name to get a consistent color
    final int hash = lesson.hashCode.abs();
    return colors[hash % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    final Color cardAccentColor = getRandomColor();
    
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(
                color: cardAccentColor.withOpacity(0.15),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: cardAccentColor,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.event,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        formatDate(date),
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      Text(
                        time,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.school, size: 18, color: cardAccentColor),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          lesson,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(height: 1),
            Container(
              padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton.icon(
                    onPressed: () {
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) =>ReschedulePopup()),
);

                    },
                    icon: Icon(Icons.schedule, size: 16),
                    label: Text('Reschedule'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.grey[700],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () {
                      // Add functionality to cancel
                    },
                    icon: Icon(Icons.cancel_outlined, size: 16),
                      label: Text('Cancel'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.red[400],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

