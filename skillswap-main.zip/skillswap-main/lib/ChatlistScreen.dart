import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ChatDetailScreen extends StatefulWidget {
  final ChatContact contact;

  const ChatDetailScreen({
    super.key,
    required this.contact,
  });

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [
    ChatMessage(
      text: "Hey 👋",
      isMe: false,
      time: DateTime.now().subtract(const Duration(minutes: 10)),
    ),
    ChatMessage(
      text: "Are you available for a New UI Project",
      isMe: false,
      time: DateTime.now().subtract(const Duration(minutes: 9)),
    ),
    ChatMessage(
      text: "Hello!",
      isMe: true,
      time: DateTime.now().subtract(const Duration(minutes: 8)),
    ),
    ChatMessage(
      text: "yes, have some space for the new task",
      isMe: true,
      time: DateTime.now().subtract(const Duration(minutes: 7)),
    ),
    ChatMessage(
      text: "Cool, should I share the details now?",
      isMe: false,
      time: DateTime.now().subtract(const Duration(minutes: 6)),
    ),
    ChatMessage(
      text: "Yes Sure, please",
      isMe: true,
      time: DateTime.now().subtract(const Duration(minutes: 5)),
    ),
    ChatMessage(
      text: "Great, here is the SOW of the Project",
      isMe: false,
      time: DateTime.now().subtract(const Duration(minutes: 4)),
      attachment: Attachment(
        name: "UI Brief.docx",
        size: "105.48 KB",
        icon: Icons.insert_drive_file_outlined,
      ),
    ),
  ];

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF6C5CE7),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                    child: _buildMessageList(),
                  ),
                ),
              ),
              _buildMessageInput(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          CircleAvatar(
            backgroundImage: NetworkImage(widget.contact.imageUrl),
            radius: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.contact.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  widget.contact.status,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          CircleAvatar(
            backgroundColor: Colors.grey.shade200,
            radius: 18,
            child: IconButton(
              icon: const Icon(
                Icons.email_outlined,
                size: 18,
                color: Colors.black54,
              ),
              onPressed: () {},
            ),
          ),
          const SizedBox(width: 8),
          CircleAvatar(
            backgroundColor: Colors.grey.shade200,
            radius: 18,
            child: IconButton(
              icon: const Icon(
                Icons.phone_outlined,
                size: 18,
                color: Colors.black54,
              ),
              onPressed: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final message = _messages[index];
        return _buildMessageItem(message);
      },
    );
  }

  Widget _buildMessageItem(ChatMessage message) {
    return Align(
      alignment: message.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: message.isMe ? Colors.white : const Color(0xFF5B4DE5),
                borderRadius: BorderRadius.circular(20),
              ),
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.7,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: TextStyle(
                      color: message.isMe ? Colors.black87 : Colors.white,
                      fontSize: 14,
                    ),
                  ),
                  if (message.attachment != null) ...[
                    const SizedBox(height: 8),
                    _buildAttachment(message.attachment!),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttachment(Attachment attachment) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            attachment.icon,
            color: Colors.white,
            size: 20,
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                attachment.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                attachment.size,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 10,
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Icon(
            Icons.download,
            color: Colors.white.withOpacity(0.7),
            size: 18,
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: const Color(0xFF6C5CE7),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(
              Icons.attach_file_outlined,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.emoji_emotions_outlined,
                    color: Colors.grey,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      decoration: const InputDecoration(
                        hintText: "OK, Let me check",
                        border: InputBorder.none,
                        hintStyle: TextStyle(color: Colors.grey),
                      ),
                    ),
                  ),
                  const Icon(
                    Icons.mic_none_rounded,
                    color: Colors.grey,
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          CircleAvatar(
            backgroundColor: Colors.white,
            radius: 22,
            child: IconButton(
              icon: const Icon(
                Icons.send,
                color: Color(0xFF6C5CE7),
                size: 20,
              ),
              onPressed: () {
                if (_messageController.text.isNotEmpty) {
                  setState(() {
                    _messages.add(
                      ChatMessage(
                        text: _messageController.text,
                        isMe: true,
                        time: DateTime.now(),
                      ),
                    );
                    _messageController.clear();
                  });
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ChatContact {
  final String name;
  final String status;
  final String imageUrl;
  final String lastMessage;
  final DateTime lastMessageTime;
  final bool isOnline;
  final bool isTyping;
  final int unreadCount;

  ChatContact({
    required this.name,
    required this.status,
    required this.imageUrl,
    required this.lastMessage,
    required this.lastMessageTime,
    this.isOnline = false,
    this.isTyping = false,
    this.unreadCount = 0,
  });
}

class ChatMessage {
  final String text;
  final bool isMe;
  final DateTime time;
  final Attachment? attachment;

  ChatMessage({
    required this.text,
    required this.isMe,
    required this.time,
    this.attachment,
  });
}

class Attachment {
  final String name;
  final String size;
  final IconData icon;

  Attachment({
    required this.name,
    required this.size,
    required this.icon,
});
}
