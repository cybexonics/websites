class User {
  final String id; // Add this field
  final String name;
  final String email;
  final String profilePicture;
  final List<String> skillsTeach;
  final List<String> skillsLearn;
  final bool verified;
  final double rating;
  final String location;

  User({
    required this.id, // Add this to the constructor
    required this.name,
    required this.email,
    required this.profilePicture,
    required this.skillsTeach,
    required this.skillsLearn,
    required this.verified,
    required this.rating,
    required this.location, required List<String> skillsToTeach, required imageUrl, required List<String> skillsToLearn,
  });

  // Factory method to create User from API response
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['_id'] ?? '', // Assign id
      name: json['name'] ?? 'Unknown',
      email: json['email'] ?? '',
      profilePicture: json['profilePicture'] ?? 'https://via.placeholder.com/150',
      skillsTeach: List<String>.from(json['skillsTeach'] ?? []),
      skillsLearn: List<String>.from(json['skillsLearn'] ?? []),
      verified: json['verified'] ?? false,
      rating: (json['rating'] ?? 0).toDouble(),
      location: json['location'] ?? 'Unknown', skillsToTeach: [], imageUrl: null, skillsToLearn: [],
    );
  }

  get imageUrl => null;
}
