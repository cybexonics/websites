import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UserManagementPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("User Management", style: TextStyle(color: Colors.black)),
        backgroundColor: Color.fromARGB(255, 245, 246, 247),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          ListTile(
            title: Text("Approve/Block Users", style: TextStyle(color: Colors.black)),
            subtitle: Text("Manage user access and permissions"),
            leading: Icon(Icons.verified_user, color: Colors.blue),
            trailing: Icon(Icons.arrow_forward_ios, color: Colors.blue),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ApproveBlockUsersPage()),
              );
            },
          ),
          Divider(color: Colors.blue),
          ListTile(
            title: Text("Handle Disputes", style: TextStyle(color: Colors.black)),
            subtitle: Text("Resolve issues between users"),
            leading: Icon(Icons.warning, color: Colors.blue),
            trailing: Icon(Icons.arrow_forward_ios, color: Colors.blue),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HandleDisputesPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class ApproveBlockUsersPage extends StatefulWidget {
  @override
  _ApproveBlockUsersPageState createState() => _ApproveBlockUsersPageState();
}

class _ApproveBlockUsersPageState extends State<ApproveBlockUsersPage> {
  List<dynamic> users = [];
  final String apiUrl = "http://localhost:5000/api/users"; // Change to actual backend URL

  @override
  void initState() {
    super.initState();
    fetchUsers();
  }

  Future<void> fetchUsers() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        setState(() {
          users = json.decode(response.body);
        });
      } else {
        print("Failed to load users");
      }
    } catch (e) {
      print("Error fetching users: $e");
    }
  }

  Future<void> updateUserStatus(String userId, String status) async {
    final updateUrl = "$apiUrl/$userId"; // API endpoint for updating user status
    try {
      final response = await http.put(
        Uri.parse(updateUrl),
        headers: {"Content-Type": "application/json"},
        body: json.encode({"status": status}),
      );

      if (response.statusCode == 200) {
        setState(() {
          users = users.map((user) {
            if (user["_id"] == userId) {
              return {...user, "status": status};
            }
            return user;
          }).toList();
        });
      } else {
        print("Failed to update user status");
      }
    } catch (e) {
      print("Error updating user status: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Approve/Block Users", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blue,
      ),
      backgroundColor: Colors.white,
      body: users.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index) {
                return Card(
                  color: Colors.white,
                  child: ListTile(
                    title: Text(users[index]["name"], style: TextStyle(color: Colors.black)),
                    subtitle: Text("Status: ${users[index]["status"]}", style: TextStyle(color: Colors.black)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: () => updateUserStatus(users[index]["_id"], "Approved"),
                          child: Text("Approve", style: TextStyle(color: Colors.blue)),
                        ),
                        TextButton(
                          onPressed: () => updateUserStatus(users[index]["_id"], "Blocked"),
                          child: Text("Block", style: TextStyle(color: Colors.red)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class HandleDisputesPage extends StatelessWidget {
  final List<Map<String, String>> disputes = [
    {"user": "Alice Brown", "issue": "Missed lesson", "status": "Pending"},
    {"user": "David Lee", "issue": "Inappropriate behavior", "status": "Under Review"},
    {"user": "Sophia Wilson", "issue": "Refund request", "status": "Resolved"}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Handle Disputes", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blue,
      ),
      backgroundColor: Colors.white,
      body: ListView.builder(
        itemCount: disputes.length,
        itemBuilder: (context, index) {
          return Card(
            color: Colors.white,
            child: ListTile(
              title: Text(disputes[index]["user"]!, style: TextStyle(color: Colors.black)),
              subtitle: Text("Issue: ${disputes[index]["issue"]}", style: TextStyle(color: Colors.black)),
              trailing: Text("Status: ${disputes[index]["status"]}", style: TextStyle(color: Colors.black)),
            ),
          );
        },
      ),
    );
  }
}
