import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skillswap/styles/signup_style.dart';

class User {
  final String id;
  final String name;
  final String email;
  final String? username;
  final String? bio;
  final String? phone;
  final String? location;
  final String? website;
  final String? profileImage;
  final String? availability;
  final double? rating;
  final List<dynamic>? reviews;
  final List<dynamic>? matchRequests;
  final List<String>? skillsTeach;
  final List<String>? skillsLearn;
  final List<dynamic>? certifications;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.username,
    this.bio,
    this.phone,
    this.location,
    this.website,
    this.profileImage,
    this.availability,
    this.rating,
    this.reviews,
    this.matchRequests,
    this.skillsTeach,
    this.skillsLearn,
    this.certifications,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['_id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      username: json['username'] ?? '@${json['name']?.toString().toLowerCase().replaceAll(' ', '') ?? ''}',
      bio: json['bio'] ?? '',
      phone: json['phone'] ?? '',
      location: json['location'] ?? '',
      website: json['website'] ?? '',
      profileImage: json['profilePicture'] ?? '',
      availability: json['availability'] ?? 'Available',
      rating: json['rating']?.toDouble() ?? 0.0,
      reviews: json['reviews'] != null ? List<dynamic>.from(json['reviews']) : [],
      matchRequests: json['matchRequests'] != null ? List<dynamic>.from(json['matchRequests']) : [],
      skillsTeach: json['skillsTeach'] != null 
          ? (json['skillsTeach'] is List 
              ? List<String>.from(json['skillsTeach'].map((item) => item.toString())) 
              : [json['skillsTeach'].toString()])
          : [],
      skillsLearn: json['skillsLearn'] != null 
          ? (json['skillsLearn'] is List 
              ? List<String>.from(json['skillsLearn'].map((item) => item.toString())) 
              : [json['skillsLearn'].toString()])
          : [],
      certifications: json['certifications'] != null ? List<dynamic>.from(json['certifications']) : [],
    );
  }
}
class EditProfileScreen extends StatefulWidget {
  final String userId;
  
  const EditProfileScreen({
    super.key, 
    required this.userId,
  });

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
final TextEditingController fullNameController = TextEditingController();
final TextEditingController usernameController = TextEditingController();
final TextEditingController bioController = TextEditingController();
final TextEditingController emailController = TextEditingController();
final TextEditingController phoneController = TextEditingController();
final TextEditingController locationController = TextEditingController();
final TextEditingController websiteController = TextEditingController();
final TextEditingController availabilityController = TextEditingController();
final TextEditingController skillsTeachController = TextEditingController(); // Added
final TextEditingController skillsLearnController = TextEditingController(); // Added


  bool showEmail = true;
  bool showPhone = false;
  bool isEditing = false;
  bool isLoading = true;
  String? errorMessage;
  
  File? profileImageFile;
  String? profileImageUrl;
  File? certificationsFile;
  String? certificationsFileName;
  
  User? userData;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      // Retrieve user_id from SharedPreferences
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      String? user_id = prefs.getString('user_id');

      print('User_id from SharedPreferences: $user_id');

      if (user_id == null) {
        setState(() {
          isLoading = false;
          errorMessage = 'User ID not found in SharedPreferences';
        });
        return;
      }

      final response = await http.get(
        Uri.parse('http://192.168.29.167:5000/api/users/$user_id'),
      );

      if (response.statusCode == 200) {
        // Debugging
        print('API Response Body: ${response.body}');
      
        // Safely decode the JSON
        final dynamic decodedData = json.decode(response.body);
        print('API Response Type: ${decodedData.runtimeType}');
      
        // Parse the user data
        try {
          userData = User.fromJson(decodedData);
        
          // Populate controllers with user data
          fullNameController.text = userData?.name ?? '';
          emailController.text = userData?.email ?? '';
          usernameController.text = userData?.username ?? '';
          bioController.text = userData?.bio ?? '';
          phoneController.text = userData?.phone ?? '';
          locationController.text = userData?.location ?? '';
          websiteController.text = userData?.website ?? '';
          availabilityController.text = userData?.availability ?? 'Available';
          skillsLearnController.text = userData?.skillsLearn?.join(', ') ?? '';
          skillsTeachController.text = userData?.skillsTeach?.join(', ') ?? '';
          profileImageUrl = userData?.profileImage;
        
          setState(() {
            isLoading = false;
          });
        } catch (e) {
          print('Error parsing user data: $e');
          setState(() {
            isLoading = false;
            errorMessage = 'Error parsing user data: $e';
          });
        }
      } else {
        setState(() {
          isLoading = false;
          errorMessage = 'Failed to load user data. Status code: ${response.statusCode}';
        });
      }
    } catch (e) {
      print('Error fetching user data: $e');
      setState(() {
        isLoading = false;
        errorMessage = 'Error fetching user data: $e';
      });
    }
  }

  Future<void> updateProfile() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {


 // Retrieve user_id from SharedPreferences
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      String? user_id = prefs.getString('user_id');

      print('User_id from SharedPreferences: $user_id');

      if (user_id == null) {
        setState(() {
          isLoading = false;
          errorMessage = 'User ID not found in SharedPreferences';
        });
        return;
      }



      var request = http.MultipartRequest(
        'PUT',
        Uri.parse('http://192.168.29.167:5000/api/users/$user_id'),
      );

      // Add text fields
      request.fields['name'] = fullNameController.text;
      request.fields['email'] = emailController.text;
      request.fields['location'] = locationController.text;
      request.fields['availability'] = availabilityController.text;
      
      if (bioController.text.isNotEmpty) {
        request.fields['bio'] = bioController.text;
      }
      
      if (phoneController.text.isNotEmpty) {
        request.fields['phone'] = phoneController.text;
      }
      
      if (websiteController.text.isNotEmpty) {
        request.fields['website'] = websiteController.text;
      }
      
      // Add skills as JSON arrays
      if (userData?.skillsLearn != null && userData!.skillsLearn!.isNotEmpty) {
        request.fields['skillsLearn'] = json.encode(userData!.skillsLearn);
      }
      
      if (userData?.skillsTeach != null && userData!.skillsTeach!.isNotEmpty) {
        request.fields['skillsTeach'] = json.encode(userData!.skillsTeach);
      }

      // Add profile image if selected
      if (profileImageFile != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'profileImage',
            profileImageFile!.path,
            filename: path.basename(profileImageFile!.path),
          ),
        );
      }

      // Add certifications if selected
      if (certificationsFile != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'certifications',
            certificationsFile!.path,
            filename: path.basename(certificationsFile!.path),
          ),
        );
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully')),
        );
        
        setState(() {
          isEditing = false;
          isLoading = false;
        });
        
        // Refresh user data
        fetchUserData();
      } else {
        setState(() {
          isLoading = false;
          errorMessage = 'Failed to update profile. Status code: ${response.statusCode}';
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update profile: $responseBody')),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMessage = 'Error updating profile: $e';
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating profile: $e')),
      );
    }
  }

  Future<void> _pickProfileImage() async {
    if (!isEditing) return;
    
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    
    if (image != null) {
      setState(() {
        profileImageFile = File(image.path);
      });
    }
  }

  Future<void> _pickCertificationsFile() async {
    if (!isEditing) return;
    
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    
    if (result != null) {
      setState(() {
        certificationsFile = File(result.files.single.path!);
        certificationsFileName = result.files.single.name;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Selected file: ${result.files.single.name}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text(
          'Profile',
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (isEditing) {
                // Save changes
                updateProfile();
              } else {
                // Enable editing
                setState(() {
                  isEditing = true;
                });
              }
            },
            child: Text(
              isEditing ? 'Save' : 'Edit',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: isLoading 
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
              ? Center(child: Text('Error: $errorMessage'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildProfilePicture(),
                      if (isEditing)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: _buildCertificationsList(),
                        ),
                      const SizedBox(height: 24),
                     _buildTextField('Full Name', fullNameController),
_buildTextField('Username', usernameController),
_buildTextField('Bio', bioController, maxLines: 3),
_buildTextField('Email', emailController, icon: Icons.email_outlined),
_buildTextField('Phone', phoneController, icon: Icons.phone_outlined),
_buildTextField('Location', locationController, icon: Icons.location_on_outlined),
_buildTextField('Website', websiteController, icon: Icons.language_outlined),
_buildTextField('Availability', availabilityController, icon: Icons.access_time),
_buildTextField('Skills to Teach', skillsTeachController, icon: Icons.school),
_buildTextField('Skills to Learn', skillsLearnController, icon: Icons.lightbulb),

                      const SizedBox(height: 24),
                      if (isEditing) _buildPrivacySettings(),
                      const SizedBox(height: 16),
                      if (isEditing) _buildSaveButton(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildProfilePicture() {
    return Center(
      child: Stack(
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage: profileImageFile != null 
                ? FileImage(profileImageFile!) as ImageProvider
                : (profileImageUrl != null && profileImageUrl!.isNotEmpty
                    ? NetworkImage(profileImageUrl!) 
                    : const NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_2025-02-08_160701%5B1%5D-b1ZXH3GnwugL7WPusVSwIuaALxsZ41.png')),
          ),
          if (isEditing)
            Positioned(
              right: 0,
              bottom: 0,
              child: GestureDetector(
                onTap: _pickProfileImage,
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: primaryColor,
                  child: const Icon(Icons.camera_alt, color: Colors.white, size: 18),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {IconData? icon, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        enabled: isEditing,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: icon != null ? Icon(icon) : null,
          border: const OutlineInputBorder(),
          filled: !isEditing,
          fillColor: !isEditing ? Colors.grey.shade100 : null,
        ),
      ),
    );
  }

  Widget _buildPrivacySettings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Privacy Settings', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        SwitchListTile(
          title: const Text('Show Email'),
          subtitle: const Text('Display email on your public profile'),
          value: showEmail,
          onChanged: (bool value) => setState(() => showEmail = value),
        ),
        SwitchListTile(
          title: const Text('Show Phone Number'),
          subtitle: const Text('Display phone on your public profile'),
          value: showPhone,
          onChanged: (bool value) => setState(() => showPhone = value),
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: updateProfile,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF6C5CE7),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        child: const Text('Save Changes', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  Widget _buildCertificationsList() {
    if (userData?.certifications == null || userData!.certifications!.isEmpty) {
      return const Text("No certifications uploaded", style: TextStyle(fontStyle: FontStyle.italic));
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Certifications:", style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...userData!.certifications!.map((cert) => 
          Text("• ${cert.toString().split('/').last}", style: const TextStyle(fontSize: 14))
        ).toList(),
      ],
    );
  }
}

