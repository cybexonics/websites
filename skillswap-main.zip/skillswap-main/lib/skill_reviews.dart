import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class NewReviewsScreen extends StatefulWidget {
  @override
  _NewReviewsScreenState createState() => _NewReviewsScreenState();
}

class _NewReviewsScreenState extends State<NewReviewsScreen> {
  List<Map<String, dynamic>> _reviews = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchReviews();
  }

  Future<void> fetchReviews() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? user_id = prefs.getString('user_id');
    print('User_id: $user_id');
    final url = Uri.parse('http://192.168.29.167:5000/api/review/user/$user_id');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);

        setState(() {
          _reviews = data.map((review) {
            return {
              "name": review["name"] ?? "Anonymous",
              "rating": (review["rating"] ?? 0.0).toDouble(),
              "timeAgo": review["timeAgo"] ?? "N/A",
              "review": review["review"] ?? "No review available",
              "likes": review["likes"] ?? 0,
              "comments": review["comments"] ?? 0,
            };
          }).toList();
          _isLoading = false;
        });
      } else {
        throw Exception("Failed to load reviews");
      }
    } catch (error) {
      print("Error fetching reviews: $error");
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text(
          'User Reviews',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _reviews.isEmpty
              ? Center(child: Text("No reviews available"))
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: _reviews.length,
                  itemBuilder: (context, index) {
                    final review = _reviews[index];
                    return _buildReviewCard(
                      name: review["name"],
                      rating: review["rating"],
                      timeAgo: review["timeAgo"],
                      review: review["review"],
                      likes: review["likes"],
                      comments: review["comments"],
                    );
                  },
                ),
    );
  }

  Widget _buildReviewCard({
    required String name,
    required double rating,
    required String timeAgo,
    required String review,
    required int likes,
    required int comments,
  }) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.deepPurple,
                  child: Text(
                    name[0].toUpperCase(),
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        timeAgo,
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: List.generate(5, (index) {
                return Icon(
                  index < rating ? Icons.star : Icons.star_border,
                  color: Colors.amber,
                  size: 20,
                );
              }),
            ),
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.deepPurple.shade50,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                review,
                style: TextStyle(fontSize: 14, color: Colors.black87),
              ),
            ),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.thumb_up, size: 20, color: Colors.deepPurple),
                    SizedBox(width: 4),
                    Text('$likes'),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.comment, size: 20, color: Colors.deepPurple),
                    SizedBox(width: 4),
                    Text('$comments'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
