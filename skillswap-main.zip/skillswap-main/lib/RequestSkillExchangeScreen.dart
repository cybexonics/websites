import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:skillswap/exchange_skill.dart';
import 'package:skillswap/models/user.dart';

class RequestSkillExchangeScreen extends StatefulWidget {
  final String userId;

  const RequestSkillExchangeScreen({Key? key, required this.userId })
      : super(key: key);

  @override
  _RequestSkillExchangeScreenState createState() =>
      _RequestSkillExchangeScreenState();
}

class _RequestSkillExchangeScreenState
    extends State<RequestSkillExchangeScreen> {
  User? user;
  String _selectedDuration = '1 hour';
  bool _isRemote = true;
  final _messageController = TextEditingController();

  // Add these variables for reviews
  List<dynamic> _reviews = [];
  bool _isLoadingReviews = true;
  String? _reviewError;

  // Add these variables for the review form
  final _reviewController = TextEditingController();
  double _userRating = 3.0;
 

  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _fetchUserReviews();
  }

  Future<void> _fetchUserData() async {
    final url =
        Uri.parse('http://192.168.29.167:5000/api/users/${widget.userId}');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('API Response: $data');

        if (data is List && data.isNotEmpty) {
          setState(() {
            user = User.fromJson(data[0]); // Assuming first user in list
          });
        } else if (data is Map<String, dynamic>) {
          setState(() {
            user = User.fromJson(data);
          });
        } else {
          print('Unexpected data format: $data');
        }
      } else {
        print('Failed to load user data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  // Add this method to fetch reviews
  Future<void> _fetchUserReviews() async {
    setState(() {
      _isLoadingReviews = true;
      _reviewError = null;
    });

    final url = Uri.parse(
        'http://192.168.29.167:5000/api/review/user/${widget.userId}');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('Reviews API Response: $data');

        setState(() {
          _reviews = data is List ? data : [];
          _isLoadingReviews = false;
        });
      } else {
        print('Failed to load reviews. Status code: ${response.statusCode}');
        setState(() {
          _reviewError = 'Failed to load reviews';
          _isLoadingReviews = false;
        });
      }
    } catch (e) {
      print('Error fetching reviews: $e');
      setState(() {
        _reviewError = 'Error loading reviews';
        _isLoadingReviews = false;
      });
    }
  }

  // Add this method to submit a review
  Future<void> _submitReview() async {
    final url = Uri.parse('http://192.168.29.167:5000/api/review/add');
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? user_id = prefs.getString('user_id');
    String? user_name = prefs.getString('user_name');
    print('User_name: $user_name');
    print('User_id: $user_id');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "user": widget.userId,
          "reviewer": user_id,
          "name": user_name,
          "rating": _userRating,
          "review": _reviewController.text,
          "timeAgo": "Just now",
          "likes": 0
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Review added successfully
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Review added successfully')),
        );
        // Refresh reviews
        _fetchUserReviews();
      } else {
        print('Failed to add review. Status code: ${response.statusCode}');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to add review')),
        );
      }
    } catch (e) {
      print('Error adding review: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error adding review')),
      );
    }
  }

  // Add this method to show the review dialog
  void _showAddReviewDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Review'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Rate this user'),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  5,
                  (index) => IconButton(
                    icon: Icon(
                      Icons.star,
                      color: index < _userRating ? Colors.amber : Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        _userRating = index + 1;
                      });
                      Navigator.pop(context);
                      _showAddReviewDialog(); // Reopen with updated rating
                    },
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _reviewController,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: 'Write your review here...',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _submitReview();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6C5CE7),
            ),
            child: const Text('Submit Review'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C5CE7),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Request Skill Exchange',
          style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: user == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildUserProfile(),
                  const SizedBox(height: 24),
                  _buildSkillsExchange(),
                  const SizedBox(height: 32),
                  _buildMessage(),
                  const SizedBox(height: 24),
                  _buildReviewSection(),
                  const SizedBox(height: 24),
                ],
              ),
            ),
      bottomNavigationBar: _buildSendRequest(),
    );
  }

  Widget _buildUserProfile() {
    return Row(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundImage:
              NetworkImage(user?.imageUrl ?? 'https://via.placeholder.com/150'),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    user?.name ?? 'Unknown User',
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.verified, color: Colors.blue, size: 20),
                ],
              ),
              Row(
                children: [
                  const Icon(Icons.location_on, size: 16, color: Colors.grey),
                  Text(user?.location ?? 'Unknown Location',
                      style: const TextStyle(color: Colors.grey)),
                ],
              ),
              Row(
                children: List.generate(
                  5,
                  (index) => Icon(
                    Icons.star,
                    size: 20,
                    color: index < (user?.rating ?? 0).floor()
                        ? Colors.amber
                        : Colors.grey,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSkillsExchange() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Skills Exchange',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildSkillCard(
                user?.skillsTeach?.join(', ') ?? 'Your Skills',
                'Skills to Teach',
                Icons.palette,
                Colors.blue.shade50,
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Icon(Icons.swap_horiz, color: Colors.grey),
            ),
            Expanded(
              child: _buildSkillCard(
                user?.skillsLearn?.join(', ') ?? 'Desired Skills',
                'Skills to Learn',
                Icons.lightbulb,
                Colors.orange.shade50,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSkillCard(
      String title, String subtitle, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 32),
          const SizedBox(height: 8),
          Text(title,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(subtitle,
              style: const TextStyle(color: Colors.grey, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildMessage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Your Message',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: _messageController,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: 'Write your message here...',
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  // Update the _buildReviewSection method
  Widget _buildReviewSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Reviews',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            // Add Review Button
            ElevatedButton.icon(
              onPressed: _showAddReviewDialog,
              icon: const Icon(Icons.rate_review, color: Colors.white),
              label: const Text('Add Review',
                  style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6C5CE7),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Show loading indicator while fetching
        if (_isLoadingReviews)
          const Center(child: CircularProgressIndicator())

        // Show error message if there's an error
        else if (_reviewError != null)
          Center(
            child: Column(
              children: [
                Text(_reviewError!, style: const TextStyle(color: Colors.red)),
                ElevatedButton(
                  onPressed: _fetchUserReviews,
                  child: const Text('Retry'),
                ),
              ],
            ),
          )

        // Show "No reviews" message if the list is empty
        else if (_reviews.isEmpty)
          const Center(child: Text('No reviews yet'))

        // Show the reviews
        else
          Column(
            children: _reviews.reversed.map((review) {
              print(review);
              final name = review['reviewer']?['name'] ?? 'Anonymous';
              final rating = (review['rating'] ?? 0).toDouble();

              // Format the date
              String timeAgo = review['createdAt'] ?? 'Just now';
              if (review['createdAt'] != null) {
                DateTime reviewDate =
                    DateTime.parse(review['createdAt']).toLocal();
                Duration difference = DateTime.now().difference(reviewDate);

                if (difference.inDays > 0) {
                  timeAgo =
                      '${difference.inDays} ${difference.inDays == 1 ? 'day' : 'days'} ago';
                } else if (difference.inHours > 0) {
                  int hours = difference.inHours;
                  int minutes = difference.inMinutes.remainder(60);
                  timeAgo = minutes > 0
                      ? '$hours ${hours == 1 ? 'hour' : 'hours'}, $minutes ${minutes == 1 ? 'minute' : 'minutes'} ago'
                      : '$hours ${hours == 1 ? 'hour' : 'hours'} ago';
                } else {
                  timeAgo =
                      '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
                }
              }

              final comment = review['review'] ?? 'No comment';
              final likes = review['likes'] ?? 0;
              final comments = review['comments']?.length ?? 0;

              return _buildReview(
                  name, rating, timeAgo, comment, likes, comments);
            }).toList(),
          ),
      ],
    );
  }

  Widget _buildReview(String name, double rating, String timeAgo, String review,
      int likes, int comments) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Profile Picture (Dummy avatar for now)

          // Review Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name, Rating, and Time Ago in One Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.grey[300], // Default background
                      child: Text(
                        name.isNotEmpty
                            ? name[0].toUpperCase()
                            : '?', // First letter as placeholder
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 12), // Space between avatar and text

                    Expanded(
                      child: Text(
                        name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      '$rating ★',
                      style: const TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  ],
                ),

                const SizedBox(height: 4),
                // Review Text
                Container(
                  margin: const EdgeInsets.only(left: 50),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(review, style: const TextStyle(fontSize: 14)),
                ),
                const SizedBox(height: 8),
                // Like & Comment Section
                Container(
                  margin: const EdgeInsets.only(left: 50),
                  child: Row(
                    children: [
                      Icon(Icons.thumb_up, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text('$likes', style: TextStyle(color: Colors.grey[600])),
                      const SizedBox(width: 10),
                      Text(
                        timeAgo,
                        style:
                            const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                const Divider(), // Adds separation between reviews
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendRequest() {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: Container(
        margin: EdgeInsets.all(5),
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ExchangeSkillScreen(
                  user: user,
                  yourSkills: user?.skillsTeach ?? [],
                  theirSkills: user?.skillsLearn ?? [],
                  duration: _selectedDuration,
                  location: _isRemote ? 'Remote' : 'In-person',
                  messagePreview: _messageController.text,
                  userA: '',
                  userB: widget.userId,
                ),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF6C5CE7),
          ),
          child: const Text('Send Exchange Request',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              )),
        ),
      ),
    );
  }
}
