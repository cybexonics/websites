package com.example.skillswap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
