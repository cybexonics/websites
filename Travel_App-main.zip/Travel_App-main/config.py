MONGO_URI = "mongodb://localhost:27017/travel_app"
JWT_SECRET_KEY = "b90b4ea7ebb843b105804adbfeacb9f3d9004d2610c52c48"
