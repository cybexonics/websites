document.addEventListener('DOMContentLoaded', function() {
    const userInfo = document.querySelector('.user-info');
    const userDropdown = document.querySelector('.user-info .dropdown');

    userInfo.addEventListener('click', function() {
        userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
    });

    document.addEventListener('click', function(event) {
        if (!userInfo.contains(event.target)) {
            userDropdown.style.display = 'none';
        }
    });

    // Navigation
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.sidebar a');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            sections.forEach(section => {
                section.style.display = section.id === targetId ? 'block' : 'none';
            });
        });
    });

    // Show dashboard by default
    document.getElementById('dashboard').style.display = 'block';

    // Product Category Dropdown
    const productDropdown = document.querySelector('.product-dropdown');
    const productDropdownMenu = document.querySelector('.product-dropdown-menu');

    productDropdown.addEventListener('click', function() {
        productDropdownMenu.style.display = productDropdownMenu.style.display === 'block' ? 'none' : 'block';
    });

    document.addEventListener('click', function(event) {
        if (!productDropdown.contains(event.target)) {
            productDropdownMenu.style.display = 'none';
        }
    });
});
// JavaScript functionality can be added if needed for editing or deleting actions
document.addEventListener('DOMContentLoaded', function () {
// Sample JavaScript functions for edit and delete can be added here if necessary.

// Edit and delete buttons event listeners
const editBtns = document.querySelectorAll('.edit-btn');
    const deleteBtns = document.querySelectorAll('.delete-btn');

    // Example edit button handler
    editBtns.forEach(button => {
        button.addEventListener('click', function() {
            alert('Edit functionality will be implemented here');
        });
    });

    // Example delete button handler
    deleteBtns.forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this item?')) {
                // Implement delete functionality here
                alert('Item deleted');
            }
        });
    });
});
