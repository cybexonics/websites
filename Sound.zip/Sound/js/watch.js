function loadSmartwatches() {
    const productList = document.getElementById('productList');
    if (!productList) {
        console.error('Element with id "productList" not found in the DOM.');
        return;
    }

    productList.innerHTML = '<p>Loading products...</p>'; // Show loading message

    fetch('http://127.0.0.1:5000/smartwatches') // Assuming GET method
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            productList.innerHTML = ''; // Clear loading message

            data.forEach(product => {
                const productItem = document.createElement('div');
                productItem.className = 'product-item';

                // Image URL is directly provided in the data
                let imageUrl = product.image_url; // No need to concatenate anything

                // Create clickable product card
                productItem.innerHTML = `
                    <a href="product-info.html?product_id=${encodeURIComponent(product.id)}" class="product-link">
                        <img src="${imageUrl}" 
                             alt="${product.name}" 
                             onerror="if (!this.dataset.errorHandled) { 
                                 this.dataset.errorHandled = true; 
                                 this.src='http://192.168.29.122:5000/uploads/default-image.jpg'; 
                             }">
                        <p>${product.name}</p>
                        <h1 class="price">Rs.${product.price}</h1>
                    </a>
                `;

                // Add event listener to the product card
                productItem.addEventListener('click', () => {
                    // Redirect to the product info page with product ID
                    window.location.href = `product-info.html?product_id=${product.id}`;
                });

                productList.appendChild(productItem);
            });
        })
        .catch(error => {
            console.error('Error loading smartwatches:', error);
            productList.innerHTML = '<p>Failed to load products. Please try again later.</p>';
        });
}

document.addEventListener('DOMContentLoaded', loadSmartwatches);
