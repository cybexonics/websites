// Fetch Products from Backend and Display
function loadProducts() {
    fetch('http://127.0.0.1:5000/headphones')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Log the fetched array to the console
            console.log('Fetched Products Array:', data);

            const productList = document.getElementById('product-list');
            productList.innerHTML = '';

            data.forEach(product => {
                const productItem = document.createElement('div');
                productItem.className = 'product-item';

                // Use the image_url directly as it is a full URL
                const imageUrl = product.image_url;

                // Create product item structure
                productItem.innerHTML = `
                    <img 
                        src="${imageUrl}" 
                        alt="${product.name}" 
                        class="product-image" />
                    <p>${product.name}</p>
                    <h1 class="price">Rs.${product.price}</h1>
                `;

                // Add event listener to the entire product card
                productItem.addEventListener('click', () => {
                    // Redirect to the productInfoDetails page with product ID
                    window.location.href = `product-info.html?product_id=${product.id}`;
                });

                // Append product item to the list
                productList.appendChild(productItem);
            });
        })
        .catch(error => console.error('Error loading products:', error));
}

// Call loadProducts on page load
window.onload = loadProducts;
