document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    if (productId) {
        loadProductDetails(productId);
    } else {
        alert("Product ID is missing in the URL.");
        console.error("Product ID not found in the URL");
    }
});

function loadProductDetails(productId) {
    fetch(`http://127.0.0.1:5000/earphone-details/6780ad3dadb157bcc3761e16`, {
        method: 'GET',
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(productDetails => {
            const productDetailsContainer = document.getElementById('product-details');
            if (productDetailsContainer) {
                productDetailsContainer.innerHTML = `
                    <div class="product-detail">
                        <img 
                            src="${productDetails.image_url}" 
                            alt="${productDetails.name}" 
                            class="product-detail-image" />
                        <h1>${productDetails.name}</h1>
                        <h2 class="price">Rs.${productDetails.price}</h2>
                        <p>${productDetails.description}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            const productDetailsContainer = document.getElementById('product-details');
            productDetailsContainer.innerHTML = `<p>Error loading product details. Please try again later.</p>`;
            console.error('Error fetching product details:', error);
        });
}
