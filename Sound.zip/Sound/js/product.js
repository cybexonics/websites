  // Function to redirect to the payment page with product details
  function redirectToPayment(productName, productPrice, productImage) {
    if (!productName || !productPrice) {
    alert("Product details are missing!");
    return;
    }
    
    // Store product details in localStorage
    localStorage.setItem('productName', productName);
    localStorage.setItem('productPrice', productPrice);
    localStorage.setItem('productImage', productImage || ''); // If image is not provided, store an empty string
    
    // Redirect to the payment page
    window.location.href = "payment.html";
    }
    
    // Attach event listeners to all "Buy Now" buttons after the DOM is loaded
    document.addEventListener("DOMContentLoaded", function () {
    // Select all buttons with the class 'buy-now'
    const buyNowButtons = document.querySelectorAll(".buy-now");
    
    buyNowButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Get product details from the button's data attributes
      const productName = this.getAttribute("data-name");
      const productPrice = this.getAttribute("data-price");
      const productImage = this.getAttribute("data-image");
    
      // Call the function to redirect to the payment page with the product details
      redirectToPayment(productName, productPrice, productImage);
    });
    });
    });
    
    
            // Function to add item to the cart
            function addToCart(event) {
                const button = event.target.closest('.add-to-cart'); // Get the closest "Add to Cart" button
                const productName = button.getAttribute('data-name'); // Get product name
                const productPrice = button.getAttribute('data-price'); // Get product price
                const productImage = button.getAttribute('data-image'); // Get product image
        
                // Retrieve the existing cart from localStorage or initialize an empty array
                let cart = JSON.parse(localStorage.getItem('cart')) || [];  
                
                // Add the new item to the cart
                cart.push({ 
                    name: productName, 
                    price: productPrice, 
                    image: productImage 
                });
        
                // Save the updated cart back to localStorage
                localStorage.setItem('cart', JSON.stringify(cart));
        
                // Redirect to the view cart page
                window.location.href = "view-cart.html";
            }
        
            // Attach event listeners to all "Add to Cart" buttons
            document.addEventListener("DOMContentLoaded", function () {
                const addToCartButtons = document.querySelectorAll(".add-to-cart");
                addToCartButtons.forEach((button) => {
                    button.addEventListener("click", addToCart);
                });
            });