function autoScroll() {
    const gallery = document.getElementById('gallery-container');
    let scrollAmount = 0;
    const scrollStep = 2; // Adjust this value to control the speed of scrolling
    const scrollInterval = setInterval(() => {
      gallery.scrollLeft += scrollStep;
      scrollAmount += scrollStep;
      if (scrollAmount >= gallery.scrollWidth - gallery.clientWidth) {
        clearInterval(scrollInterval);
        setTimeout(() => {
          gallery.scrollLeft = 0;
          autoScroll();
        }, 2000); // Adjust this value to control the delay before restarting the scroll
      }
    }, 20); // Adjust this value to control the smoothness of scrolling
  }

  window.onload = autoScroll;