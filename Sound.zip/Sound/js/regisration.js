
        // Handle Registration and Display Success Message
        function handleRegistration(event) {
            event.preventDefault(); // Prevent the default form submission

            const username = document.getElementById("username").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const confirmPassword = document.getElementById("confirm-password").value;

            // Basic validation for matching passwords
            if (password !== confirmPassword) {
                alert("Passwords do not match!");
                return false;
            }

            // Simulate a successful registration
            document.getElementById("registrationForm").style.display = "none"; // Hide the form
            document.getElementById("successMessage").style.display = "block"; // Show the success message

            // Redirect after a delay (2 seconds)
            setTimeout(function() {
                window.location.href = "login.html"; // Redirect to login page
            }, 2000);

            return false; // Prevent default form submission behavior
        }
    