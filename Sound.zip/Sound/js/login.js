function validateForm() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Simple email validation
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false; // Prevent form submission
    }

    // Check if password is empty
    if (password.trim() === "") {
        alert("Please enter your password.");
        return false; // Prevent form submission
    }

    // If validation passes, redirect to the home page
    window.location.href = "indev.html"; // Replace with your actual home page URL
    return false; // Prevent form from submitting the traditional way
}
