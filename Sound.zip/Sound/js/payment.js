   // Load cart from localStorage
   const cart = JSON.parse(localStorage.getItem('cart')) || [];
   const paymentCartItemsContainer = document.getElementById('payment-cart-items');
   const paymentTotalContainer = document.getElementById('payment-total');

   // Function to update the payment total
   function updatePaymentTotal() {
       const total = cart.reduce((sum, item) => sum + (parseFloat(item.price.replace('Rs. ', '').replace(',', '')) * item.quantity), 0);
       paymentTotalContainer.textContent = `Total: Rs. ${total.toFixed(2)}`;
   }

   // Function to display cart items on the payment page
   function displayPaymentCartItems() {
       paymentCartItemsContainer.innerHTML = ''; // Clear existing items

       if (cart.length === 0) {
           paymentCartItemsContainer.innerHTML = '<tr><td colspan="4">Your cart is empty.</td></tr>';
           return;
       }

       cart.forEach((item) => {
           const cartItemElement = document.createElement('tr');
           cartItemElement.innerHTML = `
               <td>${item.name}</td>
               <td>Rs. ${item.price}</td>
               <td>${item.quantity}</td>
               <td>Rs. ${(parseFloat(item.price.replace('Rs. ', '').replace(',', '')) * item.quantity).toFixed(2)}</td>
           `;
           paymentCartItemsContainer.appendChild(cartItemElement);
       });

       updatePaymentTotal();
   }

   // Function to handle payment confirmation
   function confirmPayment() {
       alert('Your payment has been successfully processed!');
       // Clear the cart after payment
       localStorage.removeItem('cart');
   }

   // Display the cart items and total on page load
   displayPaymentCartItems();