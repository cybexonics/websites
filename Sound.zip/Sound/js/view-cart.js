      // Load cart from localStorage
      const cart = JSON.parse(localStorage.getItem('cart')) || [];

      const cartItemsContainer = document.getElementById('cart-items');
      const cartTotalContainer = document.getElementById('cart-total');

      // Function to update the cart total
      function updateCartTotal() {
          const total = cart.reduce((sum, item) => sum + (parseFloat(item.price.replace('Rs. ', '').replace(',', '')) * item.quantity), 0);
          cartTotalContainer.textContent = `Total: Rs. ${total.toFixed(2)}`;
      }

      // Function to display cart items
      function displayCartItems() {
          cartItemsContainer.innerHTML = ''; // Clear existing items

          if (cart.length === 0) {
              cartItemsContainer.innerHTML = '<tr><td colspan="5">Your cart is empty.</td></tr>';
              return;
          }

          cart.forEach((item, index) => {
              const cartItemElement = document.createElement('tr');

              cartItemElement.innerHTML = `
                  <td>
                      <img src="${item.image}" alt="${item.name}" class="product-img">
                      ${item.name}
                  </td>
                  <td>${item.price}</td>
                  <td>
                      <div class="quantity-controls">
                          <button onclick="updateQuantity(${index}, -1)">-</button>
                          <input type="number" value="${item.quantity}" min="1" id="quantity-${index}" onchange="updateQuantityFromInput(${index})">
                          <button onclick="updateQuantity(${index}, 1)">+</button>
                      </div>
                  </td>
                  
                  <td><span class="remove" onclick="removeItem(${index})">Remove</span></td>
              `;

              cartItemsContainer.appendChild(cartItemElement);
          });

          updateCartTotal();
      }

      // Update the quantity of a specific item
      function updateQuantity(index, change) {
          cart[index].quantity += change;
          if (cart[index].quantity < 1) cart[index].quantity = 1; // Prevent going below 1
          localStorage.setItem('cart', JSON.stringify(cart)); // Save to localStorage
          displayCartItems(); // Re-render cart
      }

      // Update quantity from input field
      function updateQuantityFromInput(index) {
          const input = document.getElementById(`quantity-${index}`);
          const newQuantity = parseInt(input.value);
          if (newQuantity > 0) {
              cart[index].quantity = newQuantity;
          } else {
              cart[index].quantity = 1; // Prevent invalid quantities
          }
          localStorage.setItem('cart', JSON.stringify(cart)); // Save to localStorage
          displayCartItems(); // Re-render cart
      }

      // Remove an item from the cart
      function removeItem(index) {
          cart.splice(index, 1); // Remove the item from the array
          localStorage.setItem('cart', JSON.stringify(cart)); // Save to localStorage
          displayCartItems(); // Re-render cart
      }

      // Display the cart items on page load
      displayCartItems();

