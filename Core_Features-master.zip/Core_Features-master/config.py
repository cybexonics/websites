class Config:
    MONGO_URI =  "mongodb+srv://siddhigandhi:Siddhi2013@cluster0.4yg1e.mongodb.net/furniture_store?retryWrites=true&w=majority&appName=Cluster0"

    