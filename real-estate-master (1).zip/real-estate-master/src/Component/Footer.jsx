import React from 'react'
import ('./Styles/Footer.css')

function Footer() {
  return (
<footer className="footer">
  <div className="footer-container">
    {/* Company Info */}
    <div className="footer-about">
      <h3>About Us</h3>
      <p>Your trusted real estate partner. Helping you find your dream home with ease and professionalism.</p>
    </div>
    {/* Quick Links */}
    <div className="footer-links">
      <h3>Quick Links</h3>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Properties</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
    {/* Contact Information */}
    <div className="footer-contact">
      <h3>Contact Us</h3>
      <p>123 Real Estate Lane, City, Country</p>
      <p>Email: info@realestate.com</p>
      <p>Phone: +1 234 567 890</p>
    </div>
    {/* Social Media Links */}
    <div className="footer-social">
      <h3>Follow Us</h3>
      <ul>
        <li><a href="#"><i className="fab fa-facebook-f" /></a></li>
        <li><a href="#"><i className="fab fa-twitter" /></a></li>
        <li><a href="#"><i className="fab fa-instagram" /></a></li>
        <li><a href="#"><i className="fab fa-linkedin-in" /></a></li>
      </ul>
    </div>
  </div>
</footer>

  )
}

export default Footer
