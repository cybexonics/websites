import React from 'react';
import './Styles/Details.css';

function Details() {
  return (
    <div className="details-container futuristic-background">
      <div className="image-wrapper futuristic-image">
        <img 
          src="/img/2bhk.jpg" 
          alt="A futuristic bedroom" 
        />
      </div>
      <div className="content-wrapper">
        <h2 className="main-title futuristic-text">Paying Guest or Co-living Options</h2>
        <p className="main-description futuristic-text">
          Explore shared and private rooms in all top cities of India with futuristic amenities.
        </p>
        <button className="action-button futuristic-button">Explore PG/ Co-living</button>
        <div className="articles-list">
          <h3 className="articles-heading futuristic-text">Best Articles on PG/ Co-living</h3>
          <p className="articles-summary futuristic-text">From beginner's checklist to pro-tips</p>
          <div className="article-card futuristic-card">
            
            <div className="article-content futuristic-text">
              <h4>How to convert your home into a PG</h4>
              <p>Oct 30, 2023</p>
            </div>
          </div>
          <div className="article-card futuristic-card">
            
            
            <div className="article-content futuristic-text">
              <h4>Where to find a PG in Noida under Rs 10,000</h4>
              <p>Oct 29, 2023</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Details;
