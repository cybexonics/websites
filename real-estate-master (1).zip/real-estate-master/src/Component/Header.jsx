import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";  // Import useLocation
import './Styles/Header.css';

const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userName, setUserName] = useState('');
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);

    const navigate = useNavigate();
    const location = useLocation();  // Hook to get current route

    useEffect(() => {
        const token = localStorage.getItem("token");
        const storedUser = localStorage.getItem("user");

        if (token && storedUser) {
            setIsLoggedIn(true);
            setUserName(JSON.parse(storedUser).name);
        } else {
            setIsLoggedIn(false);
        }

        const handleScroll = () => {
            if (window.scrollY > 100) {
                setIsScrolled(true);
            } else {
                setIsScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const handleLoginClick = () => {
        navigate("/login");
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setIsLoggedIn(false);
        setUserName('');
        navigate("/");
    };

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    // Apply the transparent-to-black effect only on the Home page (default black for others)
    const isHomePage = location.pathname === "/";  // Check if the current page is Home
    const headerClass = isHomePage && isScrolled ? 'scrolled' : 'black-bg';  // Conditional class

    return (
        <header className={`header ${headerClass}`}>
            <div className="header-container">
                <div className="logo">RealEstate.com</div>

                {/* Desktop Navigation */}
                <nav className="nav-items">
                    <Link to="/">Home</Link>
                    <div className="dropdown">
                        <span className="dropdown-link">Properties</span>
                        <div className="dropdown-menu">
                            <Link to="/properties">Properties</Link>
                            <Link to="/properties/land">Land</Link>
                            <Link to="/properties/commercial-land">Commercial Property</Link>
                            <Link to="/properties/rent">Rent</Link>
                            <Link to="/properties/buy">Buy</Link>
                        </div>
                    </div>
                    <Link to="/agents">Agents</Link>
                    <Link to="/about">About</Link>
                    <Link to="/contact">Contact</Link>
                </nav>

                {/* Header Buttons */}
                <div className="header-buttons">
                    {isLoggedIn ? (
                        <>
                            <span className="user-name">{`Welcome, ${userName}`}</span>
                            <button className="post-property-btn" onClick={handleLogout}>
                                Logout
                            </button>
                        </>
                    ) : (
                        <button className="post-property-btn" onClick={handleLoginClick}>
                            Login
                        </button>
                    )}
                </div>

                {/* Hamburger Menu */}
                <div className="hamburger" onClick={toggleMenu}>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <nav className="mobile-menu">
                    <Link to="/" onClick={toggleMenu}>Home</Link>
                    <div className="mobile-dropdown">
                        <span onClick={toggleDropdown}>Properties</span>
                        {isDropdownOpen && (
                            <div className="mobile-dropdown-menu">
                                <Link to="/properties/land" onClick={toggleMenu}>Land</Link>
                                <Link to="/properties/commercial-land" onClick={toggleMenu}>Commercial Land</Link>
                                <Link to="/properties/commercial-property" onClick={toggleMenu}>Commercial Property</Link>
                                <Link to="/properties/rent-buy" onClick={toggleMenu}>Rent/Buy</Link>
                                <Link to="/properties/plot" onClick={toggleMenu}>Plot</Link>
                            </div>
                        )}
                    </div>
                    <Link to="/agents" onClick={toggleMenu}>Agents</Link>
                    <Link to="/about" onClick={toggleMenu}>About</Link>
                    <Link to="/contact" onClick={toggleMenu}>Contact</Link>
                </nav>
            )}
        </header>
    );
};

export default Header;
