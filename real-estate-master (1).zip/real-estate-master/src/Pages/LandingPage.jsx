import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import Icon from '@mdi/react';
import { mdiPlay } from '@mdi/js';
import { Search, MapPin, Home, Building, CreditCard, Phone } from 'lucide-react';
import '../styles/LandingPage.css';

const LandingPage = () => {

  const [featuredProperties, setFeaturedProperties] = useState([]); 

  const realEstateOptions = [
    { title: "Residential Plots", image: "img/residential-plots.webp" },
    { title: "Commercial Plots", image: "img/comertial-plots.jpg" },
    { title: "Lands", image: "img/lands.webp" },
    { title: "Renting Property", image: "img/rent.jpg" },
    { title: "Buying Property", image: "img/Buying-property_2.png" }
  ];

  const propertyTypes = ['Buy', 'Rent', 'Property', 'Commercial', 'Land'];
  const popularLocations = [
    { name: 'Surya Nagari', image: '/img/surya-nagari.jpg' },
    { name: 'TandulWadi', image: '/img/tandulwadi.jpg' },
    { name: 'Pragati Nagar', image: '/img/pragati-nagar.jpeg' },
    { name: 'Rui', image: '/img/rui.jpeg' },
    { name: 'Kasba', image: '/img/kasba.jpeg' },
    { name: 'Undavadi', image: '/img/undavadi.jpeg' },
  ];
   // Fetch featured properties when the component mounts
   useEffect(() => {
    // Fetch data from the API
    fetch('http://localhost:5000/api/properties')
      .then(response => response.json())
      .then(data => {
        // Limit the results to 4 properties
        setFeaturedProperties(data.slice(0, 4));
      })
      .catch(error => console.error('Error fetching properties:', error));
  }, []);



  const [propertyType, setPropertyType] = useState('Buy');
  const [citySearch, setCitySearch] = useState('');
  const [filteredProperties, setFilteredProperties] = useState([]);

  // Fetch properties based on type and location
  const fetchProperties = () => {
    let apiUrl = 'http://localhost:5000/api/properties';

    // Adjust API endpoint based on property type
    switch (propertyType) {
      case 'Rent':
        apiUrl = 'http://localhost:5000/api/renting_properties';
        break;
      case 'Plots':
        apiUrl = 'http://localhost:5000/api/land_properties';
        break;
      case 'Commercial':
        apiUrl = 'http://localhost:5000/api/commercial_plots';
        break;
      case 'PG/Co-living':
        apiUrl = 'http://localhost:5000/api/properties';
        break;
      case 'Buy':
        apiUrl = 'http://localhost:5000/api/buying_properties';
        break;
      default:
        apiUrl = 'http://localhost:5000/api/properties';
    }

    // Add location as a query parameter
    apiUrl += `?location=${encodeURIComponent(citySearch)}`;

    // Fetch data
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        setFilteredProperties(data);
      })
      .catch((error) => console.error('Error fetching properties:', error));
  };

  const filteredPropertiesRef = useRef(null);

  const handleSearchClick = () => {
    // Scroll to the filtered properties section
    if (filteredPropertiesRef.current) {
      filteredPropertiesRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
    fetchProperties(); // Ensure this is also called
  };

  return (
    <div className="min-h-screen">



      {/* Hero Section with Search */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Find Your Perfect Home in Baramati</h1>
            <p className="hero-subtitle">
              Search from over 1 million properties across India
            </p>
          </div>

          {/* Property Type Tabs */}
          <div className="property-tabs">
            <div className="tabs-container">
              {['Buy', 'Rent', 'PG/Co-living', 'Commercial', 'Plots'].map((type) => (
                <button
                  key={type}
                  className={`tab-button ${propertyType === type ? 'active' : ''}`}
                  onClick={() => setPropertyType(type)}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Search Bar */}
          <div className="search-container">
        <div className="search-form">
          <div className="search-input-container">
            <MapPin className="search-icon" size={20} />
            <input
              type="text"
              placeholder="Enter city, locality or project"
              className="search-input"
              value={citySearch}
              onChange={(e) => setCitySearch(e.target.value)}
            />
          </div>
          <button className="search-button" onClick={handleSearchClick}>
            <Search size={20} />
            Search
          </button>
        </div>
      </div>
        </div>
      </section>
{/* Filtered Properties Section */}
<section className="section" ref={filteredPropertiesRef}>
        <div className="container">
          <h2 className="section-title">Filtered Properties</h2>
          <div className="properties-grid">
            {filteredProperties.length > 0 ? (
              filteredProperties
                .filter((property) =>
                  property.location.toLowerCase().includes(citySearch.toLowerCase())
                )
                .map((property) => (
                  <Link
                    key={property._id}
                    to={`/properties/${property.type}/${property._id}`}
                    className="property-card"
                  >
                    <div>
                      <img
                        src={property.images[0]}
                        alt={property.title}
                        className="property-images"
                      />
                      <div className="property-content">
                        <div className="rera-badge">RERA</div>
                        <h3 className="property-title">{property.title}</h3>
                        <p className="property-location">{property.location}</p>
                        <div className="property-details">
                          <span className="property-price">₹{property.price}</span>
                        </div>
                        <p className="property-meta">
                          {property.priceIncrease}% price increase in last year in {property.location}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))
            ) : (
              <p>No properties found for the selected criteria.</p>
            )}
          </div>
        </div>
      </section>

      {/* Popular Cities */}
      {/* Popular Cities */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Popular Places</h2>
          <div className="cities-grid">
            {popularLocations.map((location) => (
              <a
                key={location.name}
                href={`/properties?city=${encodeURIComponent(location.name)}&sortBy=location`}
                className="city-card"
              >
                <img
                  src={location.image}
                  alt={location.name}
                  className="city-image"
                />
                <h2>{location.name}</h2>
                <p>Discover the beauty of {location.name}</p>
                <span className="learn-more">Learn More</span>
              </a>
            ))}
          </div>
        </div>
      </section>



      {/*Updated component*/}
      <section className="explore-cards">
        <h2>Explore Real Estate Options</h2>
        <div className="cards-container">
          {realEstateOptions.map((option, index) => (
            <div key={index} className="real-estate-card card">
              <img src={option.image} alt={option.title} className="card__img" />
              <div className="card__footer">
                <span>{option.title}</span>
                <span>Discover Now</span>
              </div>

            </div>
          ))}
        </div>
      </section>

{/* Featured Properties */}
<section className="section">
  <div className="container">
    <h2 className="section-title">Featured Properties</h2>
    <div className="properties-grid">
      {featuredProperties.map((property, index) => (
        <Link 
          key={index} 
          to={`/properties/${property.type}/${property._id}`} // Include 'type' and 'id' in the URL
          className="property-card"
        >
          <div>
            <img
              src={property.images[0]} // Dynamic image source
              alt={property.title}
              className="property-images"
            />
            <div className="property-content">
              <div className="rera-badge">RERA</div>
              <h3 className="property-title">{property.title}</h3>
              <p className="property-location">{property.location}</p>
              <div className="property-details">
                <span className="property-price">₹{property.price}</span>
              </div>
              <p className="property-meta">
                {property.priceIncrease}10% price increase in last 1 year in {property.location}
              </p>
            </div>
          </div>
        </Link>
      ))}
    </div>
    {/* Button to view all properties */}
    <div className="view-all-button-container">
      <a href="/properties" className="btn-view-all">
        View All Properties
      </a>
    </div>
  </div>
</section>


{/*home details */}
      <div className="section-container">
      <div className="text-container">
        <h1>Creative Design</h1>
        <p>
          This is a sample text to describe the image and provide meaningful
          context for this section. It can be customized to match your content.
        </p>
      </div>
      <div className="image-container">
        <img
          src="D:\Study\InternShip\real-estate\real-estate\public\img\house.png"
          alt="Creative Design"
          className="half-image"
        />
      </div>
    </div>

      {/* Property Services */}
      <section className="services-section">
  <div className="wave-container">
    <svg
      className="wave"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 1440 320"
    >
      <path
        fill="#f0f4f8"
        fillOpacity="1"
        d="M0,224L80,213.3C160,203,320,181,480,170.7C640,160,800,160,960,170.7C1120,181,1280,203,1360,213.3L1440,224L1440,0L1360,0C1280,0,1120,0,960,0C800,0,640,0,480,0C320,0,160,0,80,0L0,0Z"
      ></path>
    </svg>
  </div>
  <div className="container">
    <h2 className="section-title">Our Services</h2>
    <div className="services-list">
      {[
        { icon: <Home size={48} />, title: "Buy a Home", desc: "Find your dream home", link: "/buy-home" },
        { icon: <Building size={48} />, title: "Rent a Property", desc: "Rental properties in prime locations", link: "/rent-property" },
        { icon: <CreditCard size={48} />, title: "Home Loans", desc: "Best rates for home loans", link: "/home-loans" },
        { icon: <Phone size={48} />, title: "Expert Support", desc: "24/7 customer support", link: "/support" },
      ].map((service, index) => (
        <a key={index} href={service.link} className="service-item">
          <div className="service-icon">{service.icon}</div>
          <div className="service-text">
            <h3 className="service-title">{service.title}</h3>
            <p className="service-description">{service.desc}</p>
          </div>
        </a>
      ))}
    </div>
  </div>
</section>

    </div>
  );
};

export default LandingPage;
