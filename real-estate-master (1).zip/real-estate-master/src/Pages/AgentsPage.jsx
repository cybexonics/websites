import React, { useState, useEffect } from 'react';
import './Styles/AgentsPage.css';

const AgentCard = ({ name, email, phone, address, profileImage, onCall }) => {
    return (
        <div>
            <div className="profile">
                <div className="profile-image">
                    <img src={profileImage || "https://via.placeholder.com/150"} alt={`${name} Photo`} />
                </div>
                <h2 className="profile-username">{name}</h2>
                <small className="profile-user-email">{email}</small>
                <p className="profile-user-phone">📞 {phone}</p>
                <p className="profile-user-address">🏠 {address}</p>
                <div className="profile-actions">
                    <button className="btn btn--primary" onClick={onCall}>Contact</button>
                </div>
            </div>
        </div>
    );
};

const AgentsPage = () => {
    const [agents, setAgents] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentAgent, setCurrentAgent] = useState(null);

    const [formData, setFormData] = useState({
        reasonToBuy: "Investment",
        propertyDealer: "No",
        name: "",
        phone: "",
        email: "",
        planningToBuy: "3 months",
        homeLoan: false,
        siteVisits: false,
        agreeTerms: false,
    });

    // Fetch agents from API
    useEffect(() => {
        fetch('http://localhost:5000/api/agents')
            .then((response) => response.json())
            .then((data) => {
                setAgents(data);
                setIsLoading(false);
            })
            .catch((error) => {
                console.error("Error fetching agents:", error);
                setIsLoading(false);
            });
    }, []);

    const handleCall = (agent) => {
        setCurrentAgent(agent);
        setIsModalOpen(true);
    };

    const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSend = () => {
        if (!formData.agreeTerms) {
            alert("You must agree to the Terms & Conditions and Privacy Policy.");
            return;
        }

        alert(`Details Submitted:
        Name: ${formData.name}
        Phone: ${formData.phone}
        Email: ${formData.email}
        Reason to Buy: ${formData.reasonToBuy}
        Property Dealer: ${formData.propertyDealer}
        Planning to Buy: ${formData.planningToBuy}
        Interested in Home Loan: ${formData.homeLoan ? "Yes" : "No"}
        Interested in Site Visits: ${formData.siteVisits ? "Yes" : "No"}`);
        setIsModalOpen(false);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setCurrentAgent(null);
    };

    return (
        <div>
            <h1 className="agents-page-heading">Our Agents</h1>
            {isLoading ? (
                <p>Loading agents...</p>
            ) : (
                <div className="agents-page">
                    {agents.map((agent) => (
                        <AgentCard
                            key={agent._id}
                            name={agent.name}
                            email={agent.email}
                            phone={agent.phone}
                            address={agent.address}
                            profileImage={agent.profileImage}
                            onCall={() => handleCall(agent)}
                        />
                    ))}
                </div>
            )}

            {isModalOpen && currentAgent && (
                <div className="modal-overlay">
                    <div className="modal">
                        <h2>Contact {currentAgent.name}</h2>
                        <div className="modal-form">
                            <label>
                                Your reason to buy:
                                <select
                                    name="reasonToBuy"
                                    value={formData.reasonToBuy}
                                    onChange={handleInputChange}
                                >
                                    <option value="Investment">Investment</option>
                                    <option value="Self Use">Self Use</option>
                                </select>
                            </label>

                            <label>
                                Are you a property dealer?
                                <div>
                                    <label>
                                        <input
                                            type="radio"
                                            name="propertyDealer"
                                            value="Yes"
                                            checked={formData.propertyDealer === "Yes"}
                                            onChange={handleInputChange}
                                        />
                                        Yes
                                    </label>
                                    <label>
                                        <input
                                            type="radio"
                                            name="propertyDealer"
                                            value="No"
                                            checked={formData.propertyDealer === "No"}
                                            onChange={handleInputChange}
                                        />
                                        No
                                    </label>
                                </div>
                            </label>

                            <label>
                                Name:
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    placeholder="What’s your name?"
                                />
                            </label>

                            <label>
                                Phone:
                                <input
                                    type="tel"
                                    name="phone"
                                    value={formData.phone}
                                    onChange={handleInputChange}
                                    placeholder="What’s your phone number?"
                                />
                            </label>

                            <label>
                                Email (Optional):
                                <input
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    placeholder="What’s your email address? (eg: abc@xyz.com)"
                                />
                            </label>

                            <label>
                                By when are you planning to buy the property?
                                <select
                                    name="planningToBuy"
                                    value={formData.planningToBuy}
                                    onChange={handleInputChange}
                                >
                                    <option value="3 months">3 months</option>
                                    <option value="6 months">6 months</option>
                                    <option value="More than 6 months">More than 6 months</option>
                                </select>
                            </label>

                            <label>
                                <input
                                    type="checkbox"
                                    name="homeLoan"
                                    checked={formData.homeLoan}
                                    onChange={handleInputChange}
                                />
                                I am interested in a home loan.
                            </label>

                            <label>
                                <input
                                    type="checkbox"
                                    name="siteVisits"
                                    checked={formData.siteVisits}
                                    onChange={handleInputChange}
                                />
                                I am interested in site visits.
                            </label>

                            <label>
                                <input
                                    type="checkbox"
                                    name="agreeTerms"
                                    checked={formData.agreeTerms}
                                    onChange={handleInputChange}
                                />
                                I agree to the Terms & Conditions and Privacy Policy.
                            </label>

                            <div className="modal-actions">
                                <button className="btn btn--primary" onClick={handleSend}>
                                    Send
                                </button>
                                <button className="btn btn--secondary" onClick={handleCloseModal}>
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AgentsPage;
