import React from "react";
import "./Styles/ContactPage.css";

const ContactPage = () => {
  return (
    <div>
      {/* Header */}
      <div className="header-title">
        <h1 className="h1">Contact Us</h1>
        <p>We’d love to hear from you! Reach out to us for any inquiries or assistance.</p>
      </div>

      {/* Main Content */}
      <main>
        <div className="contact-container">
          {/* Form Section */}
          <div className="form-section">
            <h2>Get in Touch</h2>
            <form>
              <label htmlFor="name">Full Name</label>
              <input type="text" id="name" name="name" placeholder="Your Name" required />

              <label htmlFor="email">Email Address</label>
              <input type="email" id="email" name="email" placeholder="Your Email" required />

              <label htmlFor="phone">Phone Number</label>
              <input type="tel" id="phone" name="phone" placeholder="Your Phone Number" required />

              <label htmlFor="message">Message</label>
              <textarea id="message" name="message" rows="5" placeholder="Your Message" required></textarea>

              <button type="submit">Send Message</button>
            </form>
          </div>

          {/* Info Section */}
          <div className="info-section">
            <h2>Contact Information</h2>
            <p>
              <strong>Address:</strong> 123 Real Estate Ave, Baramati, Pune.
            </p>
            <p>
              <strong>Email:</strong> info@realestate.com
            </p>
            <p>
              <strong>Phone:</strong> +91 8308026653
            </p>
            <p>
              <strong>Working Hours:</strong> Mon-Fri: 9:00 AM - 6:00 PM
            </p>
            <div className="map">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60650.78885018089!2d74.54919195158207!3d18.17891155928703!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc3a03bdb59287f%3A0x36e4fb47fb8d8a9d!2sBaramati%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1737095452477!5m2!1sen!2sin"
                frameBorder="0"
                allowFullScreen
                title="Google Maps"
              ></iframe>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer>
        <p>&copy; 2025 Real Estate. All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default ContactPage;
