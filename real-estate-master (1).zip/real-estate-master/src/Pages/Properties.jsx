import React, { useState, useEffect } from 'react';
import './Styles/Properties.css'; // Import the custom styles for the Properties page
import { Link, useLocation } from 'react-router-dom';

// Importing FontAwesome icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';

const Properties = () => {
    const [properties, setProperties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const location = useLocation();

    // Function to determine the API endpoint based on the current path
    const getApiEndpoint = (pathname) => {
        switch (pathname) {
            case '/properties/properties':
                return 'http://localhost:5000/api/properties';
            case '/properties/rent':
                return 'http://localhost:5000/api/renting_properties';
            case '/properties/land':
                return 'http://localhost:5000/api/land_properties';
            case '/properties/commercial-land':
                return 'http://localhost:5000/api/commercial_plots';
            case '/properties/rent':
                return 'http://localhost:5000/api/renting-properties';
            case '/properties/buy':
                return 'http://localhost:5000/api/buying_properties'
            default:
                return 'http://localhost:5000/api/properties';
        }
    };

    useEffect(() => {
        // Fetch properties from the API dynamically based on the route
        const fetchProperties = async () => {
            const apiEndpoint = getApiEndpoint(location.pathname); // Get API endpoint based on pathname
            try {
                setLoading(true);
                const response = await fetch(apiEndpoint);
                if (!response.ok) {
                    throw new Error('Failed to fetch properties');
                }
                const data = await response.json();
                setProperties(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchProperties();
    }, [location.pathname]); // Re-run the effect when the pathname changes

    if (loading) {
        return <p>Loading properties...</p>;
    }

    if (error) {
        return <p>Error: {error}</p>;
    }

    return (
        <div className="properties-page">
            <header className="properties-header">
                <h1>Properties</h1>
                <p>Find your dream home from our wide range of properties</p>
            </header>

            <section className="properties-list">
    {properties.map(property => (
        <Link
            key={property._id}
            to={`/properties/${property.type}/${property._id}`} // Include type in the URL
            className="property-card"
        >
            <img
                src={property.images[0]} // Display only the first image
                alt={property.title}
                className="property-imagee"
            />
            <div className="property-details">
                <h2>{property.title}</h2>
                <div className="property-location">
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="location-icon" />
                    <p>{property.location}</p>
                </div>
                <p>Ownership: {property.owner}</p>
                <p>Price: {property.price || 'Contact for price'}</p>
            </div>
        </Link>
    ))}
</section>

        </div>
    );
};

export default Properties;
