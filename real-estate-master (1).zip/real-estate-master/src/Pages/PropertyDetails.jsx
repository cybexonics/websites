import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './Styles/PropertyDetails.css'; // Custom styles for the Property Details page

const PropertyDetails = () => {
    const { id, type } = useParams(); // Extract 'id' and 'type' from the route
    const [property, setProperty] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // State for the modal
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    // Define API endpoint based on type
    const apiEndpoints = {
        land_properties: `http://localhost:5000/api/land_properties/${id}`,
        properties: `http://localhost:5000/api/properties/${id}`,
        buying_properties: `http://localhost:5000/api/buying_properties/${id}`,
        commercial_plots: `http://localhost:5000/api/commercial_plots/${id}`,
        renting_properties: `http://localhost:5000/api/renting_properties/${id}`,
        // Add more types as needed
    };

    const apiEndpoint = apiEndpoints[type];




    useEffect(() => {
        const fetchProperty = async () => {
            if (!apiEndpoint) {
                setError('Invalid property type');
                setLoading(false);
                return;
            }

            try {
                const response = await fetch(apiEndpoint);
                if (!response.ok) {
                    throw new Error('Failed to fetch property details');
                }
                const data = await response.json();
                setProperty(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchProperty();
    }, [id, type]);

    const openModal = (index) => {
        setCurrentImageIndex(index);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    const showNextImage = () => {
        setCurrentImageIndex((prevIndex) =>
            prevIndex === property.images.length - 1 ? 0 : prevIndex + 1
        );
    };

    const showPreviousImage = () => {
        setCurrentImageIndex((prevIndex) =>
            prevIndex === 0 ? property.images.length - 1 : prevIndex - 1
        );
    };

    if (loading) {
        return <p className="loading-message">Loading property details...</p>;
    }

    if (error) {
        return <p className="error-message">Error: {error}</p>;
    }

    return (
        <div className="property-details-page">
            <header className="property-details-header">
                <h1>{property.title || 'Property'}</h1>
                <p>{property.description || 'No Description Available'}</p>
            </header>

            <div className="property-images">
                {property.images?.map((image, index) => (
                    <img
                        key={index}
                        src={image}
                        alt={`${property.title || 'Property'} - ${index + 1}`}
                        className="property-image"
                        onClick={() => openModal(index)}
                    />
                ))}
            </div>

            <div className="property-info">
                <h2>Details</h2>
                <p><strong>Price:</strong> {property.price || 'Not Available'}</p>
                <p><strong>Location:</strong> {property.location || 'Not Available'}</p>
                <p><strong>Plot Area:</strong> {property.area || 'Not Available'}</p>
                <p><strong>Ownership:</strong> {property.owner || 'Not Available'}</p>
                <p><strong>Sale Type:</strong> {property.status || 'Not Available'}</p>
                <p><strong>Type:</strong> {property.type || 'Not Available'}</p>
                {type === 'renting_properties' && (
                    <p><strong>Rent:</strong> {property.rent || 'Not Available'}</p>
                )}
                <p><strong>Owner Contact:</strong> {property.contact || 'Not Available'}</p>
                <p><strong>Uploaded:</strong> {new Date(property.createdAt).toLocaleDateString()}</p>
                <div className="enquire-now">
                    <button className="enquire-button">Enquire Now</button>
                </div>
            </div>

            {isModalOpen && (
                <div className="image-modal">
                    <span className="close-modal" onClick={closeModal}>&times;</span>
                    <button className="prev-button" onClick={showPreviousImage}>&lt;</button>
                    <div className="modal-image-container">
                        <img
                            src={property.images[currentImageIndex]}
                            alt={`Modal - ${property.title}`}
                            className="modal-image"
                        />
                        <p className="modal-image-info">
                            {`Image ${currentImageIndex + 1} of ${property.images.length}`}
                        </p>
                    </div>
                    <button className="next-button" onClick={showNextImage}>&gt;</button>
                </div>
            )}
        </div>
    );
};

export default PropertyDetails;
