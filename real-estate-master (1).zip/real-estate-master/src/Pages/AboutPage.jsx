import React from 'react'

import { FaBuilding, FaHandshake, FaUsers, FaPhone, FaEnvelope } from 'react-icons/fa';

import ('../styles/AboutPage.css')

function AboutPage() {
  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="about-hero">
        <h1 className="hero-title">About Us</h1>
        <p className="hero-subtitle">
          Building Dreams, One Home at a Time.
        </p>
      </section>

      {/* Who We Are Section */}
      <section className="about-section who-we-are">
        <h2>Who We Are</h2>
        <div className="content">
          <FaBuilding className="icon" />
          <p>
            At <strong>DreamSpace Realty</strong>, we bring together expertise and innovation to help you find your dream property. 
            Whether it's a family home, a commercial space, or an investment property, we make your journey seamless and enjoyable.
            we bring together expertise and innovation to help you find your dream property. 
            Whether it's a family home, a commercial space, or an investment property, we make your journey seamless and enjoyable.
          </p>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="about-section mission">
        <h2>Our Mission</h2>
        <div className="content">
          <FaHandshake className="icon" />
          <p>
            To deliver exceptional real estate services with integrity, transparency, and personalized attention, ensuring you feel confident in every step of the process.
          </p>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="about-section values">
        <h2>Our Values</h2>
        <div className="value-cards">
          <div className="card">
            <FaUsers className="card-icon" />
            <h3>Community First</h3>
            <p>We believe in creating lasting relationships with our clients and communities.</p>
          </div>
          <div className="card">
            <FaBuilding className="card-icon" />
            <h3>Excellence</h3>
            <p>Our team strives for excellence in every transaction and interaction.</p>
          </div>
          <div className="card">
            <FaHandshake className="card-icon" />
            <h3>Trust</h3>
            <p>We build trust through honesty, dedication, and ethical practices.</p>
          </div>
        </div>
      </section>

      {/* Meet Our Team Section */}
      <section className="about-section team">
        <h2>Meet Our Team</h2>
        <p>
          Our passionate team of real estate professionals is committed to helping you achieve your property goals. 
          Each member brings their unique expertise and unwavering dedication to making your journey successful.
        </p>
      </section>

      {/* Contact Section */}
      <section className="about-section contact">
        <h2>Get in Touch</h2>
        <div className="contact-info">
          <div>
            <FaPhone className="contact-icon" />
            <p>(123) 456-7890</p>
          </div>
          <div>
            <FaEnvelope className="contact-icon" />
            <p>info@dreamspacerealty.com</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="about-footer">
        <p>© 2025 DreamSpace Realty. All Rights Reserved.</p>
      </footer>
    </div>
  )
}

export default AboutPage
