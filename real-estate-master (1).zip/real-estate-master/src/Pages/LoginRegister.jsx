import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Styles/LoginRegister.css'; // External CSS for styling

function LoginRegister() {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      const data = await response.json();
      console.log('Response data:', data); // Log full response to verify
  
      if (response.ok) {
        const { token, user } = data; // Destructure token and user
        if (token && user) {
          localStorage.setItem('token', token); // Save token to localStorage
          localStorage.setItem('user', JSON.stringify(user)); // Save user info
          console.log('Login successful:', token);
          navigate('/'); // Redirect to home page
        } else {
          setError('Invalid response: Missing token or user data.');
        }
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setError('An unexpected error occurred. Please try again.');
    }
  };
  
  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await fetch('http://localhost:5000/api/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Registration successful:', data);
        setIsRegister(false); // Switch to login mode after successful registration
      } else {
        setError(data.message || 'Registration failed');
      }
    } catch (error) {
      console.error('Error during registration:', error);
      setError('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <div className='code-wrapper'>
      <div className="login-register-wrapper">
        <div className={`form-container ${isRegister ? 'register-mode' : ''}`}>
          <h2 className="form-title">{isRegister ? 'Create Account' : 'Welcome Back!'}</h2>
          
          <form 
            className="form"
            onSubmit={isRegister ? handleRegisterSubmit : handleLoginSubmit}
          >
            {isRegister && (
              <div className="form-group">
                <input 
                  type="text" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                  placeholder="Your Name" 
                  required 
                  className="input-field"
                />
              </div>
            )}

            <div className="form-group">
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="Email Address" 
                required 
                className="input-field"
              />
            </div>

            <div className="form-group">
              <input 
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                placeholder="Password" 
                required 
                className="input-field"
              />
            </div>

            <button type="submit" className="login-submit-btn">
              {isRegister ? 'Sign Up' : 'Sign In'}
            </button>
          </form>

          {error && <p className="error-message">{error}</p>}

          <div className="switch-mode">
            <p>
              {isRegister ? 'Already have an account?' : 'New here?'} 
              <button 
                className="switch-btn" 
                onClick={() => setIsRegister(!isRegister)}
              >
                {isRegister ? 'Login' : 'Register'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginRegister;
