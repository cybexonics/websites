import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Header from './Component/Header';
import Footer from './Component/Footer';
import LandingPage from './Pages/LandingPage';
import AboutPage from './Pages/AboutPage';
import Properties from './Pages/Properties';
import PropertyDetails from './Pages/PropertyDetails'; // Import Property Details Page
import AgentsPage from './Pages/AgentsPage';
import ContactPage from './Pages/ContactPage';
import LoginRegister from './Pages/LoginRegister';

function App() {
  return (
    <Router>
      <div>
        <Header />
        <div style={{ minHeight: 'calc(100vh - 200px)' }}>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/properties/land" element={<Properties />} />
            <Route path="/properties/commercial-land" element={<Properties />} />
            <Route path="/properties/rent" element={<Properties />} />
            <Route path="/properties/buy" element={<Properties />} />
            <Route path="/properties/:type/:id" element={<PropertyDetails />} />
            <Route path="/agents" element={<AgentsPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/login" element={<LoginRegister />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
