import os
class Config:
    MONGO_URI = "mongodb://127.0.0.1:27017/perfumes_db"